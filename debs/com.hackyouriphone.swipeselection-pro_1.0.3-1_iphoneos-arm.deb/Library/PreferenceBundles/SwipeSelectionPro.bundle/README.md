# SwipeSelectionPro-Localizations
The translations of SwipeSelection Pro's settings

To contribute: Fork the repo, make the correction/addition and then submit a pull request.

This is the best list of languages and their corresponding short codes I've found: http://www.opensource.apple.com/source/CF/CF-476.14/CFLocaleIdentifier.c 
