function queryProxy(app, host, port) {
    var proxies = [{host: '127.0.0.1', port: 1081}];
    
    // Bypass some internal domains.
    var internalDomains = [
                           'apple.com',
                           'itunes.com',
                           'mzstatic.com',
                           'icloud.com'
                           ];
    for (i = 0; i < internalDomains.length; i++) {
        if (isHostNameInDomain(host, internalDomains[i])) {
            return null;
        }
    }
    
    return proxies[0];
}
