function Get2FA(CodeX)    
--local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "rb"); local input1 = f:read("*all"); 	
    local http = require("socket.http")
local body, code = http.request("http://103.145.252.81:6868/Api/GetAuthyCode?Key="..CodeX.."")
if not body then error(code) end
-- save the content to a file
	toast(body);copyText(body)
end

function inputUIDX(UIDX)
local lenghtX = string.len(UIDX)
for i=1, lenghtX, 1 do
		inputText(string.sub(UIDX, i, i))
		usleep(50000)
	end	
end;

function inputPassX(PassX)
local lenghtX = string.len(PassX)
for i=1, lenghtX, 1 do
		inputText(string.sub(PassX, i, i))
		usleep(50000)
	end	
end;

function inputCode2FA(Code2FA)
local lenghtX = string.len(Code2FA)
for i=1, lenghtX, 1 do
		inputText(string.sub(Code2FA, i, i))
		usleep(50000)
	end	
end;

function inputSTT()
	
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;



function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;


usleep(500000);

 file = io.open(r(".../.../temmp/ContentX.txt",1), "w");file:write("0");file:close()
 file = io.open(r(".../.../temmp/RunOK.txt",1), "w");file:write("0");file:close()

--count number content
local fh = assert(io.popen('cd /var/mobile/Library/AutoTouch/Scripts/MAX2020/2.UpSTT/ && ls -1 /var/mobile/Library/AutoTouch/Scripts/MAX2020/2.UpSTT/ | wc -l > NumberContentSale.txt'));fh:close()
local f = io.open(r("MAX2020/2.UpSTT/NumberContentSale.txt",1), "rb"); local content = f:read("*all"); f:close(); 
local NumberContentSale = content-1

--random ContentX
local ContentX = math.random(1,NumberContentSale);usleep(10000);local ContentX = math.random(1,NumberContentSale);usleep(10000);local ContentX = math.random(1,NumberContentSale);usleep(10000);
toast(ContentX);

local f = io.open(r("MAX2020/2.UpSTT/",1)..ContentX..".txt", "rb"); local content = f:read("*all"); f:close(); 
copyText(content);

--creat ContentX.txt
 file = io.open(r(".../.../temmp/ContentX.txt",1), "w"); file:write(""..ContentX.."");file:close()
usleep(300000);
fky();usleep(300000);--hashtag();usleep(300000);
end;--function inputSTT()

function InputPostGroup()
	
	function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;



function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;



usleep(500000);

 file = io.open(r(".../.../temmp/ContentX.txt",1), "w");file:write("0");file:close()
 file = io.open(r(".../.../temmp/RunOK.txt",1), "w");file:write("0");file:close()

--count number content
local fh = assert(io.popen('cd /var/mobile/Library/AutoTouch/Scripts/MAX2020/3.PostGroup/ && ls -1 /var/mobile/Library/AutoTouch/Scripts/MAX2020/3.PostGroup/ | wc -l > NumberContentSale.txt'));fh:close()
local f = io.open(r("MAX2020/3.PostGroup/NumberContentSale.txt",1), "rb"); local content = f:read("*all"); f:close(); 
local NumberContentSale = content-1

--random ContentX
local ContentX = math.random(1,NumberContentSale);usleep(10000);local ContentX = math.random(1,NumberContentSale);usleep(10000);local ContentX = math.random(1,NumberContentSale);usleep(10000);
toast(ContentX);

local f = io.open(r("MAX2020/3.PostGroup/",1)..ContentX..".txt", "rb"); local content = f:read("*all"); f:close(); 
copyText(content);

--creat ContentX.txt
 file = io.open(r(".../.../temmp/ContentX.txt",1), "w"); file:write(""..ContentX.."");file:close()
usleep(300000);
fky();usleep(300000);--hashtag();usleep(300000);
end;--function InputPostGroup()



function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end


function Dl(biT)
--io.popen('activator send switch-off.com.a3tweaks.switch.wifi')	
io.popen("rm -f /var/mobile/Library/AutoTouch/Library/RX.zip");usleep(500000);
local http = require("socket.http")
local body, code = http.request("https://bit.ly/"..biT.."")
if not body then error(code) end	
local f = assert(io.open('/var/mobile/Library/AutoTouch/Library/RX.zip', 'wb')) ;f:write(body);f:close()
end;


--============================================================================================	
function Eate(path1,pa)
--io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
local http = require "socket.http"
http.request {
  method = "GET",
  url = "http://127.0.0.1:8080/control/start_playing?path=/"..path1..".ate";
  sink = collect
}
usleep(300000);	

--toast("==================Rq0qPNWDFmnTHAeTDRadEiGvlSDdlvMexJaJyumxBSbOxQ8Rq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTalzaTaRq0qPNWDFmnTHAeTDRadRq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTaEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTaRq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8l================")	
--toast("==================Rq0qPNWDFmnTHAeTDRadEiGvlSDdlvMexJaJyumxBSbOxQ8Rq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTalzaTaRq0qPNWDFmnTHAeTDRadRq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTaEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTaRq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8l================")	

inputText(pa);usleep(10000);
		tap(672.28, 1303.65);;usleep(200000);tap(672.28, 1303.65);;usleep(200000);tap(672.28, 1303.65);
copyText("==================Rq0qPNWDFmnTHAeTDRadEiGvlSDdlvMexJaJyumxBSbOxQ8Rq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTalzaTaRq0qPNWDFmnTHAeTDRadRq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTaEiGvlS/DdlvMexJaJyumxBSbOxQ8lzaTaRq0qPNWDFmnTHAeTDRadEiGvlS/DdlvMexJaJyumxBSbOxQ8l================")
end;--function Eate(path1,pa)
--============================================================================================	


		
function FrankyNouvaUpdate(name)
--io.popen('activator send switch-off.com.a3tweaks.switch.wifi') 
copyText("NO")	
local f = io.open("/var/mobile/Media/iTunes_Control/iTunes/.../gets", "rb"); local gets = f:read("*all"); f:close(); 
	--ky = "AKfycbxmgFsKG6puDNZ1RF4ZTAWzUmVSmuzGPEC0eCrBEYMIb0Xt3WE"
	body, code, headers, status = require("ssl.https").request("https://script.google.com/macros/s/"..gets.."/exec")
	--toast(body)
   if  body == nil then
	elseif  string.len(body) > 1000 then
local f = io.open("/var/mobile/Library/ApplePushService/.temmp/K", "rb"); local K = f:read("*all"); f:close(); 
		
		if name == "ky" then
			c = body:match(K..name.."([^/]+)")
			c = string.sub(c, 1, 2);copyText(c)
	toast("KEY ACTIVATED !!!")
		elseif name == "Cup" then
			c = body:match(K..name.."([^/]+)"..K)
			c = string.sub(c, 1, 2);copyText(c)
	toast("Start updating...")
			toast(c,10)
		elseif name == "biT" then	
			c = body:match(name.."([^/]+)"..name)
			copyText(c)	
	toast("biT  "..c)
		elseif name == "ziP" then	
			c = body:match(name.."([^/]+)"..name)
			copyText(c)
	toast("zipT  "..c)
		elseif name == "pa1" then	
			c = body:match(name.."([^/]+)"..name)
			c = string.sub(c, 1, 20);copyText(c)
	toast("pa1  "..c)
		elseif name == "pa2" then	
			c = body:match(name.."([^/]+)"..name.."FrankyNouva")
			c = string.sub(c, 1, 20);copyText(c)
	toast("pa2  "..c)
		elseif name == "pa3" then	
			c = body:match(name.."([^/]+)"..name)
			c = string.sub(c, 1, 20);copyText(c)
	toast("pa3  "..c)
		elseif name == "pa4" then	
			c = body:match(name.."([^/]+)"..name)
			c = string.sub(c, 1, 20);copyText(c)
	toast("pa4  "..c)
		elseif name == "pa5" then	
			c = body:match(name.."([^/]+)"..name)
			c = string.sub(c, 1, 20);copyText(c)
	toast("pa5  "..c)

		elseif name == "pa6" then	
			c = body:match(name.."([^/]+)"..name)
			c = string.sub(c, 1, 20);copyText(c)		
	toast("pa6  "..c)
			
			
		elseif name == "Uqu" then
			c = body:match(K..name.."([^/]+)"..name)
			copyText(c)
		local f = io.open(r(".../.../temmp/Uqu",1), "w");f:write(tostring(c));f:close()

		else;toast("KEY NOT ACTIVATED YET !!!");end;--if name == "ky" then
	   else;end;--if  body == nil then

end;--function FrankyNouva.update(name)

--=========================================================================================
function FrankyNouva(namecall,input1,input2,input3,input4,input5,input6,input7);
	namecall= tostring(namecall)
	input1= tostring(input1)
	input2= tostring(input2)
	input3= tostring(input3)
	input4= tostring(input4)
	input5= tostring(input5)
	input6= tostring(input6)
	input6= tostring(input7)
     local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/ate", "w");f:write(namecall);f:close();
	if input1 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write(tostring(input1));f:close(); end
	if input2 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write(tostring(input2));f:close(); end
	if input3 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write(tostring(input3));f:close(); end
	if input4 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write(tostring(input4));f:close(); end
	if input5 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write(tostring(input5));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write(tostring(input6));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write(tostring(input6));f:close(); end
if string.find(namecall, "fms") then namecall = "fms" else;end
if string.find(namecall, "app") then namecall = "app" else;end
	usleep(100000)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(""..crc..".../.../"..namecall..".ate")
	usleep(100000)
end;
function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function ot(name,input)
local now = os.time();local locations;repeat;local locations = findImage(r(name), 1, 0.98, region, false);until(#locations > 0) or os.time()-now>=tonumber(input);usleep(300000); 
end;
function FrankyN0uva(name)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(crc..name..".ate")	
		usleep(100000);
	return
end;
function ClearRam()
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close(); 
appKill(appZ);usleep(500000);
appActivate("com.apple.SpringBoard");
trx = [[                      LƯU Ý QUAN TRỌNG

Vui lòng không quay video tool chạy để SHOW/SHARE/KHOE nơi khác (cả inbox BẠN BÈ) tránh bị reup/nhại/cắp hoặc fb fix (RẤT NHANH) sẽ ẢNH HƯỞNG đến quyền lợi chung của anh em khác! Mọi TH VI PHẠM sẽ ngắt KEY và cấm VĨNH VIỄN mà không cần bất kì thông báo hay trách nhiệm nào. Trường hợp show trực tiếp tận mắt cho người quen ! HOA HỒNG 20% khi giới thiệu thành công !

MỘT SỐ LƯU Ý CÂN NHẮC:
- Nuôi acc cần kinh nghiệm, test nhiều.
- Nuôi ngây, nuôi ngô, k đổ do, thì, là, bị, tại.
- Acc non không dc ShareLive/AddFr/JoinG.
- Tool chỉ bổ trợ, hiệu quả ở tư duy, KN.
- Trọng yếu nuôi: KN,%trùng,ngưỡng,tần suất.
- Cập nhật KN: GroupFB/Zalo, Follow cao thủ.
- Nuôi hướng SEO, MKT thay vì SP4M thuần.

                                                Franky Nouva
                                          Chân thành cảm ơn !
]]

toast("\n\n"..trx,5);
toast("\n\n"..trx,5)
toast("⭕️ MAX2020Pre                  "..getSN(),5);
toast("⭕️ MAX2020Pre                  "..getSN(),5)
keyDown(KEY_TYPE.HOME_BUTTON);
usleep(102019.46);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(52783.12);

keyDown(KEY_TYPE.HOME_BUTTON);
usleep(14877.29);

keyDown(KEY_TYPE.HOME_BUTTON);
usleep(87010.04);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(357248.25);


touchDown(4, 369.50, 1244.60);
usleep(82661.08);
touchUp(4, 369.50, 1244.60);
usleep(2000000);
end;--function ClearRam()


function ResetApp()
	
local f = io.open(r("model",1), "rb"); local modelX = f:read("*all"); f:close(); 
if modelX == "6S" then
	--function ResetApp6s()
trx = [[                      LƯU Ý QUAN TRỌNG

Vui lòng không quay video tool chạy để SHOW/SHARE/KHOE nơi khác (cả inbox BẠN BÈ) tránh bị reup/nhại/cắp hoặc fb fix (RẤT NHANH) sẽ ẢNH HƯỞNG đến quyền lợi chung của anh em khác! Mọi TH VI PHẠM sẽ ngắt KEY và cấm VĨNH VIỄN mà không cần bất kì thông báo hay trách nhiệm nào. Trường hợp show trực tiếp tận mắt cho người quen ! HOA HỒNG 20% khi giới thiệu thành công !

MỘT SỐ LƯU Ý CÂN NHẮC:
- Nuôi acc cần kinh nghiệm, test nhiều.
- Nuôi ngây, nuôi ngô, k đổ do, thì, là, bị, tại.
- Acc non không dc ShareLive/AddFr/JoinG.
- Tool chỉ bổ trợ, hiệu quả ở tư duy, KN.
- Trọng yếu nuôi: KN,%trùng,ngưỡng,tần suất.
- Cập nhật KN: GroupFB/Zalo, Follow cao thủ.
- Nuôi hướng SEO, MKT thay vì SP4M thuần.

                                                Franky Nouva
                                          Chân thành cảm ơn !
]]
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("NO");file:close()
ClearRam();usleep(500000);
--FrankyN0uva(r(".../.../ClearRam",1));
io.popen('activator send libactivator.profile.Defaullt')
appRun("com.tigisoftware.ADManager");
ot("Reset.max2020",5);for i, v in pairs(findImage(r("Reset.max2020"), 1, 0.98, region, false)) do;
		tap(v[1],v[2]);usleep(300000);
touchDown(1, 420.82, 868.90);
usleep(66493.88);
touchUp(1, 420.82, 868.90);
usleep(618103.17);

touchDown(6, 486.51, 1152.98);
usleep(65487.58);
touchUp(6, 486.51, 1152.98);
usleep(618103.17);
toast("\n\n"..trx,6);
toast("\n\n"..trx,6)
toast("⭕️ MAX2020Pre                  "..getSN(),6);
toast("⭕️ MAX2020Pre                  "..getSN(),6);
keyDown(KEY_TYPE.HOME_BUTTON);
usleep(186936.67);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(163298.17);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(2000000);
for i, v in pairs(findImage(r("fixFacetimeAlert"), 1, 0.98, region, false)) do;
tap(515, 760);usleep(500000);end;--fixFacetimeAlert	
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("OK");file:close()				
end;--Reset.Applications.png
io.popen('activator send libactivator.profile.Default')
appKill("com.tigisoftware.ADManager");usleep(500000);  
--end;--ResetApp6s()
	
elseif modelX == "6" then	
 -- ResetApp6()
trx = [[                      LƯU Ý QUAN TRỌNG

Vui lòng không quay video tool chạy để SHOW/SHARE/KHOE nơi khác (cả inbox BẠN BÈ) tránh bị reup/nhại/cắp hoặc fb fix (RẤT NHANH) sẽ ẢNH HƯỞNG đến quyền lợi chung của anh em khác! Mọi TH VI PHẠM sẽ ngắt KEY và cấm VĨNH VIỄN mà không cần bất kì thông báo hay trách nhiệm nào. Trường hợp show trực tiếp tận mắt cho người quen ! HOA HỒNG 20% khi giới thiệu thành công !

MỘT SỐ LƯU Ý CÂN NHẮC:
- Nuôi acc cần kinh nghiệm, test nhiều.
- Nuôi ngây, nuôi ngô, k đổ do, thì, là, bị, tại.
- Acc non không dc ShareLive/AddFr/JoinG.
- Tool chỉ bổ trợ, hiệu quả ở tư duy, KN.
- Trọng yếu nuôi: KN,%trùng,ngưỡng,tần suất.
- Cập nhật KN: GroupFB/Zalo, Follow cao thủ.
- Nuôi hướng SEO, MKT thay vì SP4M thuần.

                                                Franky Nouva
                                          Chân thành cảm ơn !
]]
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("NO");file:close()
ClearRam();usleep(500000);
--FrankyN0uva(r(".../.../ClearRam",1));
io.popen('activator send libactivator.profile.Defaullt')
appRun("com.tigisoftware.ADManager");
ot("Reset.max2020",5);for i, v in pairs(findImage(r("Reset.max2020"), 1, 0.98, region, false)) do;
tap(177.57, 168.44);usleep(200000);
		tap(100, 875);usleep(200000) 

--ot("Reset.cancel",5) for i, v in pairs(findImage(r("Reset.cancel"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
tap(math.random(75,650), 1150);     usleep(10000); 
toast("\n\n"..trx,6);
toast("\n\n"..trx,6)
toast("⭕️ MAX2020Pre                  "..getSN(),6);
toast("⭕️ MAX2020Pre                  "..getSN(),6);
keyDown(KEY_TYPE.HOME_BUTTON);
usleep(186936.67);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(163298.17);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(2000000);
for i, v in pairs(findImage(r("fixFacetimeAlert"), 1, 0.98, region, false)) do;
tap(515, 760);usleep(500000);end;--fixFacetimeAlert	
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("OK");file:close()				
end;--Reset.Applications.png
io.popen('activator send libactivator.profile.Default')
appKill("com.tigisoftware.ADManager");usleep(500000);  
		
--end;--ResetApp6()	
		else;end;--elseif modelX = "6S" then
		
end;--ResetApp()

function CheckLiveAll2()
function CheckLiveAll()
keyDown(KEY_TYPE.HOME_BUTTON);
usleep(102019.46);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(500000);
--local f = io.open(r(".../.../temmp/LIVE.txt",1), "w");f:write("");f:close() 
--local f = io.open(r(".../.../temmp/GONE.txt",1), "w");f:write("");f:close()
local f = io.open(r(".../.../temmp/BLIVE.txt",1), "w");f:write("");f:close() 
local f = io.open(r(".../.../temmp/BGONE.txt",1), "w");f:write("");f:close() 
io.popen("cp -f /var/mobile/Library/AutoTouch/Scripts/MAX2020/1.ACC/ACC.txt /var/mobile/Library/AutoTouch/Scripts/.../.../temmp/ACC.txt");usleep(500000);

for CheckX = 1, count("ACC") do	
local f = io.open(r(".../.../temmp/CheckX.txt",1), "w");f:write(CheckX);f:close() 
local f = io.open(r(".../.../temmp/ACC.txt",1), "rb"); local content = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  	
local LineInUIDfile = tonumber(CheckX)-----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
--usleep(500000); --Important fix
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	local Code2FAX = UID_PASS[4]
--function CheckLive(uid)
	https = require("ssl.https")
	body, code, headers, status = https.request('https://graph.facebook.com/'..UIDX..'/picture')
		
		if headers == nil then test = "NOT image/gif"; toast("Error check, UID to live, check later",5)  --fix header-recheck
			log(""..UIDX.." Error check, UID to LIVE, check later")
		else
			test = headers["content-type"]
		      end;		
	--test = headers["content-type"]
	if (test == "image/gif") then
		--vibrate();
			--perx = CheckX/count("UIDACC")*100
			perx = (math.floor(CheckX/count("ACC")*100 * 100)/100)
		    pery = (math.floor(count("BGONE")/count("ACC")*100 * 100)/100)
			--toast(perx)
		toast(""..perx.."%  ❌ UID"..CheckX.." ("..count("BLIVE").."/"..count("BGONE").."/"..count("ACC")..") ⛔️ "..pery.."%\n\nĐang CheckLive, vui lòng:\n1.Không dừng chạy lúc này!\n2.Không thao tác gì trên máy !\n\nLƯU Ý: CheckLive rất nhanh, 1.000 acc/3p !")
			
			local f = io.open(r(".../.../temmp/BGONE.txt",1), "rb"); local BGONE = f:read("*all"); f:close();
			--local f = io.open(r("../.../temmp/BLIVE.txt",1), "rb"); local BLIVE = f:read("*all"); f:close();
			  if BGONE == "" then
	          local f = io.open(r(".../.../temmp/BGONE.txt",1), "w");f:write(LineX);f:close() 
	          else
			  local f = io.open(r(".../.../temmp/BGONE.txt",1), "a+");f:write("\n"..LineX.."");f:close() 
	          end;	
		--return 1	
	else

			perx = (math.floor(CheckX/count("ACC")*100 * 100)/100)
            pery = (math.floor(count("BGONE")/count("ACC")*100 * 100)/100)
		toast(""..perx.."%  ✅ UID"..CheckX.." ("..count("BLIVE").."/"..count("BGONE").."/"..count("ACC")..") ⛔️ "..pery.."%\n\nĐang CheckLive, vui lòng:\n1.Không dừng chạy lúc này!\n2.Không thao tác gì trên máy !\n\nLƯU Ý: CheckLive rất nhanh, 1.000 acc/3p !")
			
			--local f = io.open(r(".../.../temmp/BGONE.txt",1), "rb"); local BGONE = f:read("*all"); f:close();
			local f = io.open(r(".../.../temmp/BLIVE.txt",1), "rb"); local BLIVE = f:read("*all"); f:close();			
			  if BLIVE == "" then
	          local f = io.open(r(".../.../temmp/BLIVE.txt",1), "w");f:write(LineX);f:close() 
	          else
			  local f = io.open(r(".../.../temmp/BLIVE.txt",1), "a+");f:write("\n"..LineX.."");f:close() 
	          end;		
	end
--end;--function	
		end;--call value
	--usleep(1000000)
	end;--lpppx
--backup and creat
local date = os.date("%d_%m_%Y___%H_%M_%S");
local f = io.open(r(".../.../temmp/ACC.txt",1), "rb"); local ACCbackup = f:read("*all"); f:close(); 
local f = io.open(r(".../.../Backup/ACC_"..date..".txt",1), "w");f:write(ACCbackup);f:close()  
local f = io.open(r("MAX2020/1.ACC/BACKUP/ACC_"..date..".txt",1), "w");f:write(ACCbackup);f:close()   
usleep(10000);
--local f = io.open(r(".../.../temmp/LIVE.txt",1), "rb"); local LIVE = f:read("*all"); f:close(); 
--local f = io.open(r(".../.../temmp/GONE.txt",1), "rb"); local GONE = f:read("*all"); f:close(); 

local f = io.open(r(".../.../temmp/BLIVE.txt",1), "rb"); local BLIVE = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/BGONE.txt",1), "rb"); local BGONE = f:read("*all"); f:close(); 

local f = io.open(r(".../.../temmp/LIVE.txt",1), "w");f:write(BLIVE);f:close() 
local f = io.open(r(".../.../temmp/GONE.txt",1), "w");f:write(BGONE);f:close() 
local f = io.open(r("MAX2020/1.ACC/LIVE.txt",1), "w");f:write(BLIVE);f:close() 
local f = io.open(r("MAX2020/1.ACC/GONE.txt",1), "w");f:write(BGONE);f:close() 
 

local f = io.open(r(".../.../temmp/ACC.txt",1), "w");f:write(""..BLIVE.."\n"..BGONE.."");f:close() 
local f = io.open(r("MAX2020/1.ACC/ACC.txt",1), "w");f:write(""..BLIVE.."\n"..BGONE.."");f:close() 
local f = io.open(r("MAX2020/ReactAccList.txt",1), "w");f:write("-Không chỉnh sửa, list tự cập nhật !\n"..BLIVE);f:close() 
	
playAudio(r("Run.m4r",1), 2);
toast("CheckLive Done ! "..count("LIVE").."/"..count("GONE").."/"..count("ACC").."",15)
--FrankyN0uva(r(".../.../ResetApp",1))
local date = os.date("%d/%m/%Y");	
local f = io.open(r(".../.../temmp/d",1), "w");f:write(date);f:close() 
end;--CheckLiveAll()
local f = io.open(r(".../.../temmp/c",1), "rb"); local c = f:read("*all"); f:close(); 
if c == "OK" then CheckLiveAll(); else;end;
end;--function CheckLiveAll2()
--CheckLiveAll2()

function AutoLogin()
--for testlppx = 1, 20 do
--toast("test check "..testlppx)
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local content = f:read("*all"); f:close();  
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  
ri = IDapp
local f = io.open(r(".../.../temmp/IDapp.txt",1), "w");f:write(ri);f:close() 		
appn = ri	
file = io.open(r(".../.../temmp/login.txt",1), "w");file:write("NOT");file:close()	
local file = r("MAX2020/1.ACC/ACC.txt",1)
local f = io.open(file, "rb"); local content = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  
local LineInUIDfile = tonumber(IDapp)-----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
	
--usleep(500000); --Important fix
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]	
	
	for i = 3,6 do
		if UID_PASS[i] == nil then
		UID_PASS[i] = "Không có 2 FA hoặc 2FA sai"; --toast(UID_PASS[i])
		Code2FAX = "Không có 2 FA hoặc 2FA sai"	
			break
			elseif string.len(UID_PASS[i]) == 32 then
			Code2FAX = UID_PASS[i]; --toast(UID_PASS[i])
			break
		else    --if string.len(UID_PASS[i])
		Code2FAX = "Không có 2 FA hoặc 2FA sai"
	end;
	end;
         
--IMPORTANT !!!!!!!!!!!!!	
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
ResetApp();usleep(500000);
--FrankyN0uva(r(".../.../ResetApp",1))
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();	
appRun(appZ);usleep(5000000)
toast("Login M"..IDapp.."/"..count("LIVE").."",10)			
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')	
		for FixresetOK = 1, 3 do 
resetOK = "0";for i, v in pairs(findImage(r("Autologin.ForgetPassword"), 1, 0.98, region, false)) do;
			resetOK = "1"; break  ;end; --log("resetOK"..testlppx); 
if 	resetOK == "0" then
ResetApp();usleep(500000);
--FrankyN0uva(r(".../.../ResetApp",1))	
appRun(appZ);usleep(5000000)		
		else;end;--if 	resetOK = "0" then
		
		usleep(100000);
		end;--for FixresetOK = 1, 3 do 
	
	usleep(3000000);
	
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
	
--ip();
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
for i, v in pairs(findImage(r("Autologin.password"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(500000); 
for Lppx = 1, 3 do
toast("Login M"..IDapp.."/"..count("LIVE").." & FakeActionUser",10)	
for i, v in pairs(findImage(r("Autologin.okrequired2FA"), 1, 0.98, region, false)) do;
tap(v[1], v[2]);usleep(3000000); end;--fix NoInterNet
			
for i, v in pairs(findImage(r("Autologin.password"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(500000); 
tap(v[1]+math.random(1,420), v[2]-math.random(60,100));    usleep(math.random(500000,1200000));         
		inputText("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b"); usleep(math.random(100000,300000));	
inputUIDX(UIDX);usleep(math.random(3000000,5000000));end;
				
for i, v in pairs(findImage(r("Autologin.password"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,420), v[2]-math.random(1,20));     usleep(math.random(500000,1200000));  
inputPassX(PassX);usleep(math.random(500000,1200000));
			
for i, v in pairs(findImage(r("Autologin.login"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,200), v[2]-math.random(1,20));    usleep(math.random(2000000,3000000));  
end;--Autologin.login.png				
end;--Autologin.password
			usleep(100000);
end;--for Lppx = 1, 3 do			
--====================================      
ot("Autologin.inputCode",5);for i, v in pairs(findImage(r("Autologin.inputCode"), 1, 0.98, region, false)) do;
		toast("2FA code")				
tap(v[1]+math.random(1,100), v[2]-math.random(1,10));    usleep(math.random(500000,1200000));
copyText(Code2FAX)					
							--usleep(math.random(1500000,2500000));					
--===========login2FA
if Code2FAX == "Không có 2 FA hoặc 2FA sai" then toast(Code2FAX);else	
Get2FA(Code2FAX);usleep(math.random(2000000,3000000));end;							
--dofile("./var/mobile/Library/AutoTouch/Scripts/AuthOTP.lua")							
--===========login2FA
toast("Login M"..IDapp.."/"..count("LIVE").."",10)							
inputText("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");usleep(300000);	
inputCode2FA(clipText())				
usleep(math.random(500000,1000000));						
ot("Autologin.resendcode",5) ;for i, v in pairs(findImage(r("Autologin.resendcode"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(500000); 							
if Code2FAX == "Không có 2 FA hoặc 2FA sai" then toast(Code2FAX)					
						else
for i, v in pairs(findImage(r("Autologin.login"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,100), v[2]-math.random(1,20)); usleep(8000000);				
end;--Autologin.login.png							
							end;--end check if Code2FAX = "Không có 2 FA hoặc 2FA sai"						
							
                end;--Autologin.resendcode.png				
			    end;--Autologin.inputCode.png
				--end;--Autologin.okrequired2FA.png
			    --end;--Autologin.required2FA.png
				--usleep(50000000);      
				
--============================ 
			
if resetOK == "1" then			
toast("Login M"..IDapp.."/"..count("LIVE").." HOME",3)					
for i, v in pairs(findImage(r("Autologin.findconnect"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("Autologin.OKfindconnect"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.OKfindconnect.png 
end;--Autologin.findconnect.png
openURL("fb://profile");usleep(100000);	
openURL("fb://feed");usleep(100000);
for i, v in pairs(findImage(r("Autologin.allow"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.allow.png  						
for i, v in pairs(findImage(r("Autologin.OkCamera"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.OkCamera.png									
for i, v in pairs(findImage(r("Autologin.savelogin"), 1, 0.98, region, false)) do;
tap(math.random(410,650), v[2]-math.random(1,10)); toast("saved acc"); usleep(math.random(300000,800000));end;--Autologin.savelogin.png
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png	
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png	
for i, v in pairs(findImage(r("addnumber.notnow"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,50), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--addnumber.notnow.png		
--============================					
for i, v in pairs(findImage(r("logoHome"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.."/"..count("LIVE").." OK"); --log("ACC OK "..appn.."/"..rtes.."");
for i, v in pairs(findImage(r("fixNewfeature"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,50), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--fixNewfeature.png					
				end;--logoHome.png
				
			end;--if resetOK == "1" then	
--============================						
		--end;--Autologin.password--PASS		
	 end;--Autologin.password--UIDX			
		end;--call value
	
for i, v in pairs(findImage(r("Autologin.savelogin"), 1, 0.98, region, false)) do;
tap(math.random(410,650), v[2]-math.random(1,10)); toast("saved acc"); usleep(math.random(300000,800000));end;--Autologin.savelogin.png
toast("Login M"..IDapp.."/"..count("LIVE").." HOME",3)	
openURL("fb://profile");usleep(100000);	
openURL("fb://feed");usleep(100000);
--end;--test lppx
--io.popen('activator send switch-on.com.a3tweaks.switch.wifi')
end;--function AutoLogin()

function checklogin()
local f = io.open(r(".../.../temmp/IDapp.txt",1), "w");f:write(IDapp);f:close() 	
toast("Login M"..IDapp.."/"..count("LIVE").." & FakeActionUser",10)
for i, v in pairs(findImage(r("Autologin.allow"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.allow.png  
for i, v in pairs(findImage(r("Autologin.OkCamera"), 1, 0.98, region, false)) do;	
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.OkCamera.png
for i, v in pairs(findImage(r("Autologin.savelogin"), 1, 0.98, region, false)) do;	
tap(math.random(410,650), v[2]-math.random(1,10)); toast("saved acc"); usleep(math.random(300000,800000));end;--Autologin.savelogin.png
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;	
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png	
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;	
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png	

for i, v in pairs(findImage(r("Autologin.findconnect"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("Autologin.OKfindconnect"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.OKfindconnect.png 
end;--Autologin.findconnect.png
end;--function checklogin()	

function checkliveX()
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 	
for i, v in pairs(findImage(r("CheckActive.30days"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.." CP 30days");log("Login M"..IDapp.." CP 30days");end;--CheckActive.30days
for i, v in pairs(findImage(r("CheckActive.Covid19"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.." CP Covid19");log("Login M"..IDapp.." CP Covid19");end;--CheckActive.Covid19				
for i, v in pairs(findImage(r("CheckActive.MobileNumber"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.." CP Numbermobile");log("Login M"..IDapp.." CP Numbermobile");end;--CheckActive.MobileNumber.png				
for i, v in pairs(findImage(r("CheckActive.TempLock"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.." CP TempLock");log("Login M"..IDapp.." CP TempLock");end;--CheckActive.TempLock.png	
for i, v in pairs(findImage(r("logoHome"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.."/"..count("LIVE").." OK");end;--logoHome.png
end;
		function nomesspopup()
ot("fix.NomessPopup",5) ;for i, v in pairs(findImage(r("fix.NomessPopup"), 1, 0.98, region, false)) do; tap(v[1], v[2]);usleep(500000);end;		
for i, v in pairs(findImage(r("fix.NomessPopup2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);usleep(math.random(1000000,1500000));end;
	
	end;

--=====================================================================================================================
--=====================================================================================================================

function A6XX()
	
	
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  		
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();  		


function scrollup()

touchDown(3, 238.12, 1118.36);
usleep(50246.71);
touchMove(3, 247.35, 1091.89);
usleep(16753.25);
touchMove(3, 249.41, 1063.38);
usleep(16551.58);
touchMove(3, 259.68, 1019.59);
usleep(16561.96);
touchMove(3, 274.04, 964.61);
usleep(16616.92);
touchMove(3, 290.46, 890.30);
usleep(16746.04);
touchMove(3, 299.70, 821.07);
usleep(16455.33);
touchMove(3, 302.79, 751.82);
usleep(16750.25);
touchMove(3, 303.81, 685.65);
usleep(16567.38);
touchMove(3, 303.81, 630.67);
usleep(16660.79);
touchMove(3, 299.70, 562.46);
usleep(16827.12);
touchMove(3, 290.46, 505.44);
usleep(16845.83);
touchMove(3, 274.04, 436.21);
usleep(16617.12);
touchMove(3, 262.76, 385.30);
usleep(16782.04);
touchMove(3, 254.54, 346.61);
usleep(16376.12);
touchMove(3, 249.41, 319.13);
usleep(16597.21);
touchMove(3, 244.27, 298.75);
usleep(17098.25);
touchMove(3, 238.12, 280.43);
usleep(16587.79);
touchMove(3, 231.96, 265.17);
usleep(16607.25);
touchMove(3, 216.57, 242.76);
usleep(16792.62);
touchMove(3, 206.30, 223.42);
usleep(16633.67);
touchMove(3, 202.19, 213.24);
usleep(16552.88);
touchMove(3, 201.16, 206.10);
usleep(16866.88);
touchMove(3, 201.16, 201.01);
usleep(16645.54);
touchMove(3, 201.16, 198.97);
usleep(183492.29);
touchMove(3, 201.16, 197.95);
usleep(99903.79);
touchUp(3, 198.09, 197.95);
usleep(900502.92);

touchDown(4, 174.49, 960.54);
usleep(50193.00);
touchMove(4, 182.69, 925.94);
usleep(16739.04);
touchMove(4, 184.74, 887.24);
usleep(16941.71);
touchMove(4, 191.93, 811.89);
usleep(16125.83);
touchMove(4, 191.93, 727.39);
usleep(16736.96);
touchMove(4, 185.77, 656.13);
usleep(16649.12);
touchMove(4, 174.49, 604.20);
usleep(16726.29);
touchMove(4, 159.08, 550.24);
usleep(16616.42);
touchMove(4, 142.66, 500.35);
usleep(16792.96);
touchMove(4, 126.24, 462.67);
usleep(16627.50);
touchMove(4, 109.82, 431.12);
usleep(16575.25);
touchMove(4, 99.55, 413.80);
usleep(16408.50);
touchMove(4, 92.37, 402.61);
usleep(16626.79);
touchMove(4, 88.27, 394.46);
usleep(16606.88);
touchMove(4, 85.19, 390.39);
usleep(16737.21);
touchMove(4, 83.13, 389.38);
usleep(16646.62);
touchMove(4, 82.11, 388.36);
usleep(16620.67);
touchMove(4, 81.08, 386.32);
usleep(16661.54);
touchMove(4, 80.05, 384.29);
usleep(16732.92);
touchMove(4, 79.02, 382.25);
usleep(16597.46);
touchMove(4, 78.00, 380.22);
usleep(16669.25);
touchMove(4, 76.97, 378.18);
usleep(16735.50);
touchMove(4, 75.94, 377.16);
usleep(16609.42);
touchMove(4, 74.92, 375.13);
usleep(16709.12);
touchMove(4, 73.89, 374.11);
usleep(16673.25);
touchMove(4, 73.89, 373.07);
usleep(33312.42);
touchMove(4, 73.89, 372.05);
usleep(16746.04);
touchMove(4, 72.86, 371.04);
usleep(16586.67);
touchMove(4, 72.86, 370.02);
usleep(16704.46);
touchMove(4, 71.85, 369.00);
usleep(16784.50);
touchMove(4, 70.82, 367.98);
usleep(16594.79);
touchMove(4, 69.79, 366.96);
usleep(16672.33);
touchMove(4, 68.77, 365.95);
usleep(16726.42);
touchMove(4, 68.77, 364.93);
usleep(100019.79);
touchUp(4, 54.39, 357.80);
usleep(300000);
end;


--==================================================================================
 

function A6X()
openURL("fb://feed");usleep(2000000);	
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  		
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactNewsfeed ",15)		
local f = io.open(r(".../.../temmp/A6",1), "rb"); local A6 = f:read("*all"); f:close();
ot("Menu.inapp",5) ; for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
for LoopX = 1, A6 do

for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactNewsfeed ("..LoopX.."/"..A6..")",15)	
--back to Newsfeed
usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png

for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png

for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12); 
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(1000000,1500000)) 
--back to Newsfeed

		usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.LikePage"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
tap(v[1]+math.random(1,3), v[2]+math.random(1,50));    usleep(math.random(500000,800000));        end;---ReactNewsfeed.LikePage.png 

		
for rRandomX = 1, math.random(1,3) do
scrollup()
end;--end rRandomX 
	usleep(math.random(500000,800000)) 

for i, v in pairs(findImage(r("LikeNewsfeed.like"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)       
touchDown(3, v[1], v[2]);
usleep(617166.46);
touchUp(3, v[1], v[2]);
usleep(117166.46);
  
for i, v in pairs(findImage(r("LikeNewsfeed.react"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
	RegionReactX = {100-math.random(5,20),200-math.random(5,20),300-math.random(5,20),400-math.random(5,20)};RegionReactX = RegionReactX[math.random(1, #RegionReactX)] 
	RegionReactY = {v[2]-math.random(5,45)};RegionReactY = RegionReactY[math.random(1, #RegionReactY)]; usleep(100000);      
 tap(RegionReactX, RegionReactY);     usleep(500000); 
end;--LikeNewsfeed.react.png
	
	

	
	
--back to Newsfeed
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png			
			
for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png


for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12);
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(500000,1000000)) 
--back to Newsfeed
		
scrollup()	

			
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png
			
end;--LikeNewsfeed.like.png 
end;--Menu.inapp.png	
	
end;--end LoopX
	
end;--inapp
	
end;--A6X()

--===========================================================================================
local f = io.open(r(".../.../temmp/A6",1), "rb"); local A6 = f:read("*all"); f:close();	
if A6 == "0" then
   else
appKill(appZ);usleep(500000);
openURL("fb://feed");usleep(1000000);		
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactNewsfeed ",15)		
	A6X();usleep(100000);
	end;--if A6 == "0" then

end;--function A6XX()



function A7XX()
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();  	


function scrollup()

touchDown(3, 238.12, 1118.36);
usleep(50246.71);
touchMove(3, 247.35, 1091.89);
usleep(16753.25);
touchMove(3, 249.41, 1063.38);
usleep(16551.58);
touchMove(3, 259.68, 1019.59);
usleep(16561.96);
touchMove(3, 274.04, 964.61);
usleep(16616.92);
touchMove(3, 290.46, 890.30);
usleep(16746.04);
touchMove(3, 299.70, 821.07);
usleep(16455.33);
touchMove(3, 302.79, 751.82);
usleep(16750.25);
touchMove(3, 303.81, 685.65);
usleep(16567.38);
touchMove(3, 303.81, 630.67);
usleep(16660.79);
touchMove(3, 299.70, 562.46);
usleep(16827.12);
touchMove(3, 290.46, 505.44);
usleep(16845.83);
touchMove(3, 274.04, 436.21);
usleep(16617.12);
touchMove(3, 262.76, 385.30);
usleep(16782.04);
touchMove(3, 254.54, 346.61);
usleep(16376.12);
touchMove(3, 249.41, 319.13);
usleep(16597.21);
touchMove(3, 244.27, 298.75);
usleep(17098.25);
touchMove(3, 238.12, 280.43);
usleep(16587.79);
touchMove(3, 231.96, 265.17);
usleep(16607.25);
touchMove(3, 216.57, 242.76);
usleep(16792.62);
touchMove(3, 206.30, 223.42);
usleep(16633.67);
touchMove(3, 202.19, 213.24);
usleep(16552.88);
touchMove(3, 201.16, 206.10);
usleep(16866.88);
touchMove(3, 201.16, 201.01);
usleep(16645.54);
touchMove(3, 201.16, 198.97);
usleep(183492.29);
touchMove(3, 201.16, 197.95);
usleep(99903.79);
touchUp(3, 198.09, 197.95);
usleep(900502.92);

touchDown(4, 174.49, 960.54);
usleep(50193.00);
touchMove(4, 182.69, 925.94);
usleep(16739.04);
touchMove(4, 184.74, 887.24);
usleep(16941.71);
touchMove(4, 191.93, 811.89);
usleep(16125.83);
touchMove(4, 191.93, 727.39);
usleep(16736.96);
touchMove(4, 185.77, 656.13);
usleep(16649.12);
touchMove(4, 174.49, 604.20);
usleep(16726.29);
touchMove(4, 159.08, 550.24);
usleep(16616.42);
touchMove(4, 142.66, 500.35);
usleep(16792.96);
touchMove(4, 126.24, 462.67);
usleep(16627.50);
touchMove(4, 109.82, 431.12);
usleep(16575.25);
touchMove(4, 99.55, 413.80);
usleep(16408.50);
touchMove(4, 92.37, 402.61);
usleep(16626.79);
touchMove(4, 88.27, 394.46);
usleep(16606.88);
touchMove(4, 85.19, 390.39);
usleep(16737.21);
touchMove(4, 83.13, 389.38);
usleep(16646.62);
touchMove(4, 82.11, 388.36);
usleep(16620.67);
touchMove(4, 81.08, 386.32);
usleep(16661.54);
touchMove(4, 80.05, 384.29);
usleep(16732.92);
touchMove(4, 79.02, 382.25);
usleep(16597.46);
touchMove(4, 78.00, 380.22);
usleep(16669.25);
touchMove(4, 76.97, 378.18);
usleep(16735.50);
touchMove(4, 75.94, 377.16);
usleep(16609.42);
touchMove(4, 74.92, 375.13);
usleep(16709.12);
touchMove(4, 73.89, 374.11);
usleep(16673.25);
touchMove(4, 73.89, 373.07);
usleep(33312.42);
touchMove(4, 73.89, 372.05);
usleep(16746.04);
touchMove(4, 72.86, 371.04);
usleep(16586.67);
touchMove(4, 72.86, 370.02);
usleep(16704.46);
touchMove(4, 71.85, 369.00);
usleep(16784.50);
touchMove(4, 70.82, 367.98);
usleep(16594.79);
touchMove(4, 69.79, 366.96);
usleep(16672.33);
touchMove(4, 68.77, 365.95);
usleep(16726.42);
touchMove(4, 68.77, 364.93);
usleep(100019.79);
touchUp(4, 54.39, 357.80);
usleep(300000);
end;


--==================================================================================
 


function rU()

ranCheck = math.random(1,count("LIVE")) 		
local f = io.open(r(".../.../temmp/LIVE.txt",1), "rb"); local content = f:read("*all"); f:close(); 	
local LineInUIDfile = ranCheck  -----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
copyText(LineX)	
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
			
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	local Code2FAX = UID_PASS[4]
	copyText(UIDX); --toast(UIDX)
				
		end;--end call value	
					
end;--rU()

	



function A6X()
rU();usleep(100000)	
openURL("fb://profile/"..clipText());usleep(2000000);
	
local f = io.open(r(".../.../temmp/LoopA7",1), "rb"); local LoopA7 = f:read("*all"); f:close();		
local f = io.open(r(".../.../temmp/A7",1), "rb"); local A7 = f:read("*all"); f:close();		
ot("LikeProfile.more",5);usleep(1000000);for i, v in pairs(findImage(r("LikeProfile.more"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 	
--local f = io.open(r(".../.../temmp/A7",1), "rb"); local A7 = f:read("*all"); f:close();
A6 = 5		
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
for LoopX = 1, A6 do

for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  	
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactAccList ("..LoopX.."/"..A6..") "..LoopA7.."/"..A7,15)	
--back to Newsfeed
usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png

for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png

for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12); 
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(1000000,1500000)) 
--back to Newsfeed

		usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.LikePage"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
tap(v[1]+math.random(1,3), v[2]+math.random(1,50));    usleep(math.random(500000,800000));        end;---ReactNewsfeed.LikePage.png 

		
		
	
	
for rRandomX = 1, math.random(1,3) do
scrollup()
end;--end rRandomX 
	usleep(math.random(500000,800000)) 

for i, v in pairs(findImage(r("LikeNewsfeed.like"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)       
touchDown(3, v[1], v[2]);
usleep(617166.46);
touchUp(3, v[1], v[2]);
usleep(117166.46);
  
for i, v in pairs(findImage(r("LikeNewsfeed.react"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
	RegionReactX = {100-math.random(5,20),200-math.random(5,20),300-math.random(5,20),400-math.random(5,20)};RegionReactX = RegionReactX[math.random(1, #RegionReactX)] 
	RegionReactY = {v[2]-math.random(5,45)};RegionReactY = RegionReactY[math.random(1, #RegionReactY)]; usleep(100000);      
 tap(RegionReactX, RegionReactY);     usleep(500000); 
end;--LikeNewsfeed.react.png
	
	

	
	
--back to Newsfeed
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png			
			
for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png


for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12);
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(500000,1000000)) 
--back to Newsfeed
		
scrollup()	

			
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png
			
end;--LikeNewsfeed.like.png 
end;--Menu.inapp.png	
	
end;--end LoopX
	
end;--inapp
end;--LikeProfile.more
end;--A6X()


--===========================================================================================
local f = io.open(r(".../.../temmp/A7",1), "rb"); local A7 = f:read("*all"); f:close();	

if A7 == "0" then
   else
appKill(appZ);usleep(500000);
openURL("fb://feed");usleep(1000000);
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactAccList ",15)	
for LoopY = 1, tonumber(A7) do
local f = io.open(r(".../.../temmp/LoopA7",1), "w");f:write(LoopY);f:close()		
	A6X();usleep(100000);
		end;--for LoopY = 1, A8 do
end;--if A7 == "0" then

end;--function A7XX()


function A8XX()


local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  	
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();  	




function rU()
ranCheck = math.random(2,c0unt(r("MAX2020/ReactProfileList.txt",1))-1) 		
local f = io.open(r("MAX2020/ReactProfileList.txt",1), "rb"); local content = f:read("*all"); f:close(); 	
local LineInUIDfile = ranCheck  -----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
copyText(LineX)	
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
			
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	local Code2FAX = UID_PASS[4]
	copyText(UIDX); --toast(UIDX)
				
		end;--end call value	
					
end;--rU()



function scrollup()

touchDown(3, 238.12, 1118.36);
usleep(50246.71);
touchMove(3, 247.35, 1091.89);
usleep(16753.25);
touchMove(3, 249.41, 1063.38);
usleep(16551.58);
touchMove(3, 259.68, 1019.59);
usleep(16561.96);
touchMove(3, 274.04, 964.61);
usleep(16616.92);
touchMove(3, 290.46, 890.30);
usleep(16746.04);
touchMove(3, 299.70, 821.07);
usleep(16455.33);
touchMove(3, 302.79, 751.82);
usleep(16750.25);
touchMove(3, 303.81, 685.65);
usleep(16567.38);
touchMove(3, 303.81, 630.67);
usleep(16660.79);
touchMove(3, 299.70, 562.46);
usleep(16827.12);
touchMove(3, 290.46, 505.44);
usleep(16845.83);
touchMove(3, 274.04, 436.21);
usleep(16617.12);
touchMove(3, 262.76, 385.30);
usleep(16782.04);
touchMove(3, 254.54, 346.61);
usleep(16376.12);
touchMove(3, 249.41, 319.13);
usleep(16597.21);
touchMove(3, 244.27, 298.75);
usleep(17098.25);
touchMove(3, 238.12, 280.43);
usleep(16587.79);
touchMove(3, 231.96, 265.17);
usleep(16607.25);
touchMove(3, 216.57, 242.76);
usleep(16792.62);
touchMove(3, 206.30, 223.42);
usleep(16633.67);
touchMove(3, 202.19, 213.24);
usleep(16552.88);
touchMove(3, 201.16, 206.10);
usleep(16866.88);
touchMove(3, 201.16, 201.01);
usleep(16645.54);
touchMove(3, 201.16, 198.97);
usleep(183492.29);
touchMove(3, 201.16, 197.95);
usleep(99903.79);
touchUp(3, 198.09, 197.95);
usleep(900502.92);

touchDown(4, 174.49, 960.54);
usleep(50193.00);
touchMove(4, 182.69, 925.94);
usleep(16739.04);
touchMove(4, 184.74, 887.24);
usleep(16941.71);
touchMove(4, 191.93, 811.89);
usleep(16125.83);
touchMove(4, 191.93, 727.39);
usleep(16736.96);
touchMove(4, 185.77, 656.13);
usleep(16649.12);
touchMove(4, 174.49, 604.20);
usleep(16726.29);
touchMove(4, 159.08, 550.24);
usleep(16616.42);
touchMove(4, 142.66, 500.35);
usleep(16792.96);
touchMove(4, 126.24, 462.67);
usleep(16627.50);
touchMove(4, 109.82, 431.12);
usleep(16575.25);
touchMove(4, 99.55, 413.80);
usleep(16408.50);
touchMove(4, 92.37, 402.61);
usleep(16626.79);
touchMove(4, 88.27, 394.46);
usleep(16606.88);
touchMove(4, 85.19, 390.39);
usleep(16737.21);
touchMove(4, 83.13, 389.38);
usleep(16646.62);
touchMove(4, 82.11, 388.36);
usleep(16620.67);
touchMove(4, 81.08, 386.32);
usleep(16661.54);
touchMove(4, 80.05, 384.29);
usleep(16732.92);
touchMove(4, 79.02, 382.25);
usleep(16597.46);
touchMove(4, 78.00, 380.22);
usleep(16669.25);
touchMove(4, 76.97, 378.18);
usleep(16735.50);
touchMove(4, 75.94, 377.16);
usleep(16609.42);
touchMove(4, 74.92, 375.13);
usleep(16709.12);
touchMove(4, 73.89, 374.11);
usleep(16673.25);
touchMove(4, 73.89, 373.07);
usleep(33312.42);
touchMove(4, 73.89, 372.05);
usleep(16746.04);
touchMove(4, 72.86, 371.04);
usleep(16586.67);
touchMove(4, 72.86, 370.02);
usleep(16704.46);
touchMove(4, 71.85, 369.00);
usleep(16784.50);
touchMove(4, 70.82, 367.98);
usleep(16594.79);
touchMove(4, 69.79, 366.96);
usleep(16672.33);
touchMove(4, 68.77, 365.95);
usleep(16726.42);
touchMove(4, 68.77, 364.93);
usleep(100019.79);
touchUp(4, 54.39, 357.80);
usleep(300000);
end;


--==================================================================================
 



function A6X()
rU();usleep(100000)	
openURL("fb://profile/"..clipText().."");usleep(2000000);
ot("LikeProfile.more",5);usleep(1000000);for i, v in pairs(findImage(r("LikeProfile.more"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 	
--local f = io.open(r(".../.../temmp/A7",1), "rb"); local A7 = f:read("*all"); f:close();
A6 = 5		
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
for LoopX = 1, A6 do

for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  	
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactProfileList ("..LoopX.."/"..A6..")",15)	
--back to Newsfeed
usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png

for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png

for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12); 
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(1000000,1500000)) 
--back to Newsfeed

		usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.LikePage"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
tap(v[1]+math.random(1,3), v[2]+math.random(1,50));    usleep(math.random(500000,800000));        end;---ReactNewsfeed.LikePage.png 

		
		
	
	
for rRandomX = 1, math.random(1,3) do
scrollup()
end;--end rRandomX 
	usleep(math.random(500000,800000)) 

for i, v in pairs(findImage(r("LikeNewsfeed.like"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)       
touchDown(3, v[1], v[2]);
usleep(617166.46);
touchUp(3, v[1], v[2]);
usleep(117166.46);
  
for i, v in pairs(findImage(r("LikeNewsfeed.react"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
	RegionReactX = {100-math.random(5,20),200-math.random(5,20),300-math.random(5,20),400-math.random(5,20)};RegionReactX = RegionReactX[math.random(1, #RegionReactX)] 
	RegionReactY = {v[2]-math.random(5,45)};RegionReactY = RegionReactY[math.random(1, #RegionReactY)]; usleep(100000);      
 tap(RegionReactX, RegionReactY);     usleep(500000); 
end;--LikeNewsfeed.react.png
	
	

	
	
--back to Newsfeed
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png			
			
for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png


for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12);
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(500000,1000000)) 
--back to Newsfeed
		
scrollup()	

			
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png
			
end;--LikeNewsfeed.like.png 
end;--Menu.inapp.png	
	
end;--end LoopX
	
end;--inapp
end;--LikeProfile.more
end;--A6X()


--===========================================================================================
local f = io.open(r(".../.../temmp/A8",1), "rb"); local A8 = f:read("*all"); f:close();	

if A8 == "0" then
   else
appKill(appZ);usleep(500000);
openURL("fb://feed");usleep(1000000);
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactProfileList",15)	
for LoopY = 1, A8 do

	A6X();usleep(100000);
		end;--for LoopY = 1, A8 do
end;--if A8 == "0" then

end;--function A8XX()



function A9XX()

local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  	
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();  	




function rU()
ranCheck = math.random(2,c0unt(r("MAX2020/ReactPageList.txt",1))-1) 		
local f = io.open(r("MAX2020/ReactPageList.txt",1), "rb"); local content = f:read("*all"); f:close(); 	
local LineInUIDfile = ranCheck  -----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
copyText(LineX)	
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
			
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	local Code2FAX = UID_PASS[4]
	copyText(UIDX); --toast(UIDX)
				
		end;--end call value	
					
end;--rU()



function scrollup()

touchDown(3, 238.12, 1118.36);
usleep(50246.71);
touchMove(3, 247.35, 1091.89);
usleep(16753.25);
touchMove(3, 249.41, 1063.38);
usleep(16551.58);
touchMove(3, 259.68, 1019.59);
usleep(16561.96);
touchMove(3, 274.04, 964.61);
usleep(16616.92);
touchMove(3, 290.46, 890.30);
usleep(16746.04);
touchMove(3, 299.70, 821.07);
usleep(16455.33);
touchMove(3, 302.79, 751.82);
usleep(16750.25);
touchMove(3, 303.81, 685.65);
usleep(16567.38);
touchMove(3, 303.81, 630.67);
usleep(16660.79);
touchMove(3, 299.70, 562.46);
usleep(16827.12);
touchMove(3, 290.46, 505.44);
usleep(16845.83);
touchMove(3, 274.04, 436.21);
usleep(16617.12);
touchMove(3, 262.76, 385.30);
usleep(16782.04);
touchMove(3, 254.54, 346.61);
usleep(16376.12);
touchMove(3, 249.41, 319.13);
usleep(16597.21);
touchMove(3, 244.27, 298.75);
usleep(17098.25);
touchMove(3, 238.12, 280.43);
usleep(16587.79);
touchMove(3, 231.96, 265.17);
usleep(16607.25);
touchMove(3, 216.57, 242.76);
usleep(16792.62);
touchMove(3, 206.30, 223.42);
usleep(16633.67);
touchMove(3, 202.19, 213.24);
usleep(16552.88);
touchMove(3, 201.16, 206.10);
usleep(16866.88);
touchMove(3, 201.16, 201.01);
usleep(16645.54);
touchMove(3, 201.16, 198.97);
usleep(183492.29);
touchMove(3, 201.16, 197.95);
usleep(99903.79);
touchUp(3, 198.09, 197.95);
usleep(900502.92);

touchDown(4, 174.49, 960.54);
usleep(50193.00);
touchMove(4, 182.69, 925.94);
usleep(16739.04);
touchMove(4, 184.74, 887.24);
usleep(16941.71);
touchMove(4, 191.93, 811.89);
usleep(16125.83);
touchMove(4, 191.93, 727.39);
usleep(16736.96);
touchMove(4, 185.77, 656.13);
usleep(16649.12);
touchMove(4, 174.49, 604.20);
usleep(16726.29);
touchMove(4, 159.08, 550.24);
usleep(16616.42);
touchMove(4, 142.66, 500.35);
usleep(16792.96);
touchMove(4, 126.24, 462.67);
usleep(16627.50);
touchMove(4, 109.82, 431.12);
usleep(16575.25);
touchMove(4, 99.55, 413.80);
usleep(16408.50);
touchMove(4, 92.37, 402.61);
usleep(16626.79);
touchMove(4, 88.27, 394.46);
usleep(16606.88);
touchMove(4, 85.19, 390.39);
usleep(16737.21);
touchMove(4, 83.13, 389.38);
usleep(16646.62);
touchMove(4, 82.11, 388.36);
usleep(16620.67);
touchMove(4, 81.08, 386.32);
usleep(16661.54);
touchMove(4, 80.05, 384.29);
usleep(16732.92);
touchMove(4, 79.02, 382.25);
usleep(16597.46);
touchMove(4, 78.00, 380.22);
usleep(16669.25);
touchMove(4, 76.97, 378.18);
usleep(16735.50);
touchMove(4, 75.94, 377.16);
usleep(16609.42);
touchMove(4, 74.92, 375.13);
usleep(16709.12);
touchMove(4, 73.89, 374.11);
usleep(16673.25);
touchMove(4, 73.89, 373.07);
usleep(33312.42);
touchMove(4, 73.89, 372.05);
usleep(16746.04);
touchMove(4, 72.86, 371.04);
usleep(16586.67);
touchMove(4, 72.86, 370.02);
usleep(16704.46);
touchMove(4, 71.85, 369.00);
usleep(16784.50);
touchMove(4, 70.82, 367.98);
usleep(16594.79);
touchMove(4, 69.79, 366.96);
usleep(16672.33);
touchMove(4, 68.77, 365.95);
usleep(16726.42);
touchMove(4, 68.77, 364.93);
usleep(100019.79);
touchUp(4, 54.39, 357.80);
usleep(300000);
end;


--==================================================================================
 



function A6X()
rU();usleep(100000)	
openURL("fb://profile/"..clipText());usleep(2000000);
ot("ReactPage.Share",5);usleep(1000000);for i, v in pairs(findImage(r("ReactPage.Share"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 	
--local f = io.open(r(".../.../temmp/A7",1), "rb"); local A7 = f:read("*all"); f:close();
A6 = 5		
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
for LoopX = 1, A6 do

for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  	
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactPageList ("..LoopX.."/"..A6..")",15)	
--back to Newsfeed
usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png

for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png

for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12); 
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(1000000,1500000)) 
--back to Newsfeed

		usleep(math.random(500000,800000)) 
for i, v in pairs(findImage(r("ReactNewsfeed.LikePage"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
tap(v[1]+math.random(1,3), v[2]+math.random(1,50));    usleep(math.random(500000,800000));        end;---ReactNewsfeed.LikePage.png 

		
		
	
	
for rRandomX = 1, math.random(1,3) do
scrollup()
end;--end rRandomX 
	usleep(math.random(500000,800000)) 

for i, v in pairs(findImage(r("LikeNewsfeed.like"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)       
touchDown(3, v[1], v[2]);
usleep(617166.46);
touchUp(3, v[1], v[2]);
usleep(117166.46);
  
for i, v in pairs(findImage(r("LikeNewsfeed.react"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
	RegionReactX = {100-math.random(5,20),200-math.random(5,20),300-math.random(5,20),400-math.random(5,20)};RegionReactX = RegionReactX[math.random(1, #RegionReactX)] 
	RegionReactY = {v[2]-math.random(5,45)};RegionReactY = RegionReactY[math.random(1, #RegionReactY)]; usleep(100000);      
 tap(RegionReactX, RegionReactY);     usleep(500000); 
end;--LikeNewsfeed.react.png
	
	

	
	
--back to Newsfeed
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 				
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png			
			
for i, v in pairs(findImage(r("exitpost3"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost3.png
for i, v in pairs(findImage(r("exitpost2"), 1, 0.98, region, false)) do;tap(v[1], v[2]);     usleep(500000); end;---exitpost2.png


for i, v in pairs(findImage(r("fixReact.inLive"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(9, 448.53, 263.11);
usleep(33559.42);
touchMove(9, 446.48, 276.36);
usleep(16365.04);
touchMove(9, 446.48, 298.75);
usleep(16681.92);
touchMove(9, 446.48, 331.34);
usleep(16617.46);
touchMove(9, 445.45, 381.23);
usleep(16630.12);
touchMove(9, 441.34, 439.27);
usleep(16655.38);
touchMove(9, 438.26, 518.67);
usleep(16811.75);
touchMove(9, 438.26, 607.26);
usleep(16592.12);
touchMove(9, 438.26, 699.89);
usleep(16703.21);
touchMove(9, 443.40, 798.66);
usleep(16811.08);
touchMove(9, 455.72, 898.44);
usleep(16501.17);
touchMove(9, 475.22, 992.11);
usleep(16754.50);
touchMove(9, 497.80, 1083.73);
usleep(16655.83);
touchUp(9, 523.46, 1161.12);
usleep(16496.42);
touchDown(3, 480.35, 1024.68);
usleep(16679.42);
touchMove(3, 482.40, 1005.34);
usleep(16630.21);
touchMove(3, 482.40, 961.56);
usleep(16775.42);
touchMove(3, 491.64, 872.99);
usleep(16595.21);
touchMove(3, 510.12, 774.23);
usleep(16740.46);
touchMove(3, 540.90, 668.34);
usleep(16658.25);
touchMove(3, 577.86, 577.72);
usleep(16496.42);
touchUp(3, 581.97, 573.65);
	end;---fixReact.inLive.png				
	usleep(math.random(500000,1000000)) 
--back to Newsfeed
		
scrollup()	

			
for i, v in pairs(findImage(r("ReactNewsfeed.apart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
for i, v in pairs(findImage(r("ReactNewsfeed.OKapart"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
 tap(v[1]+math.random(1,200), v[2]+math.random(1,5));     usleep(500000);         end;---ReactNewsfeed.OKapart.png        
		end;---ReactNewsfeed.apart.png
			
end;--LikeNewsfeed.like.png 
end;--Menu.inapp.png	
	
end;--end LoopX
	
end;--inapp
end;--LikeProfile.more
end;--A6X()


--===========================================================================================
local f = io.open(r(".../.../temmp/A9",1), "rb"); local A9 = f:read("*all"); f:close();	

if A9 == "0" then
   else
appKill(appZ);usleep(500000);
openURL("fb://feed");usleep(1000000);
toast("MAX("..IDapp.."/"..count("LIVE")..") ReactPageList ",15)		
for LoopY = 1, A9 do
	A6X();usleep(100000);
		end;--for LoopY = 1, A8 do
end;--if A9 == "0" then

end;--function A9XX()



function A10XX()

local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 			
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close(); 

function Newsfeed()
toast("MAX("..IDapp.."/"..count("LIVE")..") ActionFakeUser (Newsfeed)",15)		
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(7, 68.77, 1258.87);
usleep(66392.88);
touchUp(7, 68.77, 1258.87);
usleep(1850649.67);

touchDown(2, 557.33, 1129.55);
usleep(50044.58);
touchMove(2, 562.47, 1102.07);
usleep(16715.67);
touchMove(2, 563.48, 1072.54);
usleep(16675.25);
touchMove(2, 570.67, 1028.75);
usleep(16600.96);
touchMove(2, 578.89, 984.99);
usleep(16796.12);
touchMove(2, 588.12, 942.22);
usleep(16694.62);
touchMove(2, 600.44, 893.35);
usleep(16604.92);
touchMove(2, 623.02, 822.09);
usleep(16703.88);
touchUp(2, 648.67, 749.78);
usleep(366780.67);

touchDown(3, 593.25, 1059.31);
usleep(33560.62);
touchMove(3, 605.58, 1020.61);
usleep(16596.08);
touchMove(3, 614.81, 976.83);
usleep(16694.38);
touchMove(3, 628.15, 928.99);
usleep(16731.42);
touchMove(3, 643.55, 861.78);
usleep(16502.00);
touchMove(3, 664.08, 793.57);
usleep(16712.08);
touchUp(3, 687.69, 715.18);
usleep(333379.17);

touchDown(5, 599.41, 1050.15);
usleep(83540.83);
touchMove(5, 622.00, 1026.72);
usleep(16601.08);
touchMove(5, 625.08, 996.18);
usleep(16649.67);
touchMove(5, 632.25, 962.58);
usleep(16748.58);
touchMove(5, 637.39, 928.99);
usleep(16641.25);
touchMove(5, 644.58, 896.40);
usleep(16672.17);
touchMove(5, 653.81, 853.64);
usleep(16684.50);
touchMove(5, 675.36, 779.32);
usleep(16472.38);
touchUp(5, 679.47, 775.25);
usleep(350239.42);

touchDown(6, 598.39, 1065.41);
usleep(33498.46);
touchMove(6, 603.52, 1048.11);
usleep(16572.75);
touchMove(6, 606.59, 1016.54);
usleep(16750.92);
touchMove(6, 619.94, 962.58);
usleep(16704.08);
touchMove(6, 636.36, 901.49);
usleep(16615.96);
touchMove(6, 656.89, 824.12);
usleep(16622.58);
touchMove(6, 685.63, 745.71);
usleep(16714.33);
touchUp(6, 706.16, 692.77);
usleep(950329.58);

touchDown(4, 574.78, 953.42);
usleep(50142.08);
touchMove(4, 576.83, 944.26);
usleep(16721.42);
touchMove(4, 576.83, 934.08);
usleep(16766.08);
touchMove(4, 578.89, 922.87);
usleep(16555.29);
touchMove(4, 584.01, 909.63);
usleep(16669.58);
touchMove(4, 588.12, 899.46);
usleep(16723.83);
touchMove(4, 591.20, 889.28);
usleep(16600.71);
touchMove(4, 593.25, 882.15);
usleep(16704.54);
touchMove(4, 595.31, 876.05);
usleep(16719.04);
touchMove(4, 596.33, 871.98);
usleep(16691.17);
touchMove(4, 597.36, 869.92);
usleep(16597.12);
touchMove(4, 598.39, 867.89);
usleep(33369.08);
touchMove(4, 598.39, 866.87);
usleep(133310.12);
touchUp(4, 598.39, 862.80);
usleep(550248.71);

touchDown(9, 596.33, 1005.34);
usleep(33448.21);
touchMove(9, 601.47, 982.95);
usleep(16657.33);
touchMove(9, 603.52, 952.40);
usleep(16766.62);
touchMove(9, 614.81, 908.62);
usleep(16603.88);
touchMove(9, 627.12, 860.76);
usleep(16690.62);
touchMove(9, 647.66, 794.59);
usleep(16812.67);
touchMove(9, 673.31, 721.29);
usleep(16715.17);
touchMove(9, 694.86, 652.06);
usleep(16392.75);
touchUp(9, 698.97, 647.97);
usleep(283498.17);

touchDown(8, 563.48, 939.17);
usleep(16711.29);
touchMove(8, 567.59, 926.96);
usleep(16837.38);
touchMove(8, 569.64, 905.56);
usleep(16600.12);
touchMove(8, 578.89, 877.07);
usleep(16611.58);
touchMove(8, 590.17, 846.51);
usleep(16863.83);
touchMove(8, 600.44, 822.09);
usleep(16487.83);
touchMove(8, 610.70, 796.62);
usleep(16715.08);
touchMove(8, 616.86, 781.36);
usleep(16768.17);
touchMove(8, 619.94, 768.12);
usleep(16539.88);
touchMove(8, 623.02, 754.87);
usleep(16712.75);
touchMove(8, 626.09, 736.55);
usleep(16584.83);
touchUp(8, 630.20, 732.48);
usleep(183442.00);

touchDown(1, 594.28, 944.26);
usleep(16779.54);
touchMove(1, 599.41, 923.88);
usleep(16677.17);
touchMove(1, 603.52, 878.08);
usleep(16597.83);
touchMove(1, 619.94, 784.41);
usleep(16778.25);
touchMove(1, 648.67, 665.29);
usleep(16535.67);
touchUp(1, 652.78, 661.22);
usleep(250118.54);

touchDown(4, 569.64, 835.32);
usleep(33450.62);
touchMove(4, 575.81, 813.92);
usleep(16682.62);
touchMove(4, 579.91, 794.59);
usleep(16711.75);
touchMove(4, 586.07, 778.30);
usleep(16619.54);
touchMove(4, 592.23, 765.07);
usleep(16770.71);
touchMove(4, 595.31, 755.89);
usleep(16645.17);
touchMove(4, 599.41, 747.75);
usleep(16627.04);
touchMove(4, 602.50, 740.62);
usleep(16682.00);
touchMove(4, 605.58, 734.52);
usleep(16708.17);
touchMove(4, 607.62, 729.43);
usleep(16616.83);
touchMove(4, 609.67, 726.38);
usleep(16696.29);
touchMove(4, 610.70, 724.34);
usleep(16711.50);
touchMove(4, 610.70, 722.31);
usleep(66598.29);
touchUp(4, 605.58, 719.25);
usleep(350148.33);

touchDown(7, 567.59, 1001.27);
usleep(16837.88);
touchMove(7, 570.67, 989.06);
usleep(16555.33);
touchMove(7, 572.73, 958.51);
usleep(16690.96);
touchMove(7, 585.04, 906.58);
usleep(16756.88);
touchMove(7, 607.62, 812.91);
usleep(16540.96);
touchMove(7, 637.39, 693.79);
usleep(16745.08);
touchUp(7, 641.50, 689.72);
usleep(250091.50);

touchDown(2, 551.17, 877.07);
usleep(33334.00);
touchMove(2, 558.36, 847.53);
usleep(16740.25);
touchMove(2, 561.44, 823.10);
usleep(16784.00);
touchMove(2, 570.67, 798.66);
usleep(16640.79);
touchMove(2, 581.97, 776.27);
usleep(16584.42);
touchMove(2, 594.28, 751.82);
usleep(16723.12);
touchMove(2, 605.58, 728.41);
usleep(16563.42);
touchMove(2, 615.83, 701.93);
usleep(16672.75);
touchMove(2, 624.05, 677.50);
usleep(16802.46);
touchMove(2, 629.17, 659.18);
usleep(16625.79);
touchMove(2, 632.25, 645.93);
usleep(16660.17);
touchMove(2, 635.34, 634.74);
usleep(16714.88);
touchMove(2, 637.39, 625.58);
usleep(16636.00);
touchMove(2, 640.47, 620.49);
usleep(16736.12);
touchMove(2, 642.52, 614.38);
usleep(16702.42);
touchUp(2, 654.84, 591.97);
usleep(1000000);
touchDown(6, 64.66, 1270.06);
usleep(99952.17);
touchUp(6, 64.66, 1270.06);
usleep(150236.67);

touchDown(6, 67.74, 1278.21);
usleep(66555.25);
touchUp(6, 67.74, 1278.21);
usleep(1351273.58);

touchDown(9, 438.26, 727.39);
usleep(16469.71);
touchMove(9, 426.98, 788.48);
usleep(16757.96);
touchMove(9, 418.76, 876.05);
usleep(16588.46);
touchMove(9, 418.76, 973.77);
usleep(16715.88);
touchMove(9, 419.79, 1070.50);
usleep(16858.17);
touchMove(9, 429.03, 1154.00);
usleep(16350.46);
touchMove(9, 443.40, 1221.19);
usleep(16665.04);
touchMove(9, 455.72, 1271.08);
usleep(16641.50);
touchMove(9, 469.06, 1302.63);
usleep(16462.71);
touchUp(9, 473.17, 1306.70);
usleep(3000000);
end;--Menu.inapp
end;--function Newsfeed()	
	
	
function addfriend()	
toast("MAX("..IDapp.."/"..count("LIVE")..") ActionFakeUser (Others)",15)		
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(6, 197.07, 1308.74);
usleep(66883.92);
touchUp(6, 197.07, 1308.74);
usleep(2734538.42);	
ActionFakeUserX = "0"
ot("ActionFakeUser.Confirm",3);
for i, v in pairs(findImage(r("ActionFakeUser.Confirm"), 1, 0.98, region, false)) do;ActionFakeUserX ="1";end;
for i, v in pairs(findImage(r("ActionFakeUser.AddFriend"), 1, 0.98, region, false)) do;ActionFakeUserX ="1";end;
if ActionFakeUserX == "1" then
touchDown(9, 575.81, 840.41);
usleep(16877.58);
touchMove(9, 593.25, 795.60);
usleep(16634.38);
touchMove(9, 615.83, 749.78);
usleep(16639.58);
touchMove(9, 636.36, 706.02);
usleep(16446.88);
touchMove(9, 653.81, 671.40);
usleep(16521.58);
touchMove(9, 670.23, 636.77);
usleep(16467.71);
touchUp(9, 674.34, 632.70);
usleep(216954.92);

touchDown(8, 548.09, 972.76);
usleep(16602.08);
touchMove(8, 552.20, 957.49);
usleep(16709.04);
touchMove(8, 561.44, 908.62);
usleep(16735.04);
touchMove(8, 595.31, 814.96);
usleep(16668.92);
touchMove(8, 632.25, 718.23);
usleep(16581.46);
touchMove(8, 667.16, 651.04);
usleep(16751.38);
touchUp(8, 693.84, 609.29);
usleep(200042.58);

touchDown(1, 540.90, 969.70);
usleep(16655.12);
touchMove(1, 547.06, 937.13);
usleep(16690.50);
touchMove(1, 559.39, 880.12);
usleep(16742.00);
touchMove(1, 592.23, 806.80);
usleep(16624.04);
touchMove(1, 626.09, 738.59);
usleep(16657.04);
touchMove(1, 648.67, 698.88);
usleep(16721.58);
touchMove(1, 662.02, 674.45);
usleep(16479.62);
touchUp(1, 666.13, 670.38);
usleep(183658.79);

touchDown(4, 549.12, 959.52);
usleep(16637.46);
touchMove(4, 557.33, 915.74);
usleep(16683.67);
touchMove(4, 584.01, 836.34);
usleep(16732.42);
touchMove(4, 623.02, 751.82);
usleep(16721.79);
touchMove(4, 649.70, 701.93);
usleep(16669.92);
touchMove(4, 665.11, 671.40);
usleep(16651.92);
touchUp(4, 669.20, 667.33);
usleep(183422.54);

touchDown(7, 519.36, 965.63);
usleep(33459.88);
touchMove(7, 531.67, 915.74);
usleep(16503.17);
touchMove(7, 567.59, 820.05);
usleep(16864.50);
touchMove(7, 611.73, 713.15);
usleep(16630.71);
touchMove(7, 650.73, 643.90);
usleep(52417.54);
touchUp(7, 654.84, 639.83);
usleep(764628.21);

touchDown(2, 579.91, 951.38);
usleep(33258.58);
touchMove(2, 578.89, 921.85);
usleep(16714.12);
touchMove(2, 579.91, 896.40);
usleep(16616.71);
touchMove(2, 587.09, 864.83);
usleep(16717.83);
touchMove(2, 596.33, 833.28);
usleep(16674.50);
touchMove(2, 605.58, 796.62);
usleep(16658.71);
touchMove(2, 614.81, 764.05);
usleep(16783.33);
touchMove(2, 620.97, 739.61);
usleep(16730.50);
touchMove(2, 627.12, 719.25);
usleep(16701.38);
touchMove(2, 635.34, 693.79);
usleep(16615.38);
touchMove(2, 642.52, 672.41);
usleep(16675.25);
touchMove(2, 651.76, 651.04);
usleep(16665.54);
touchMove(2, 657.92, 633.72);
usleep(16657.88);
touchMove(2, 661.00, 624.56);
usleep(16982.42);
touchMove(2, 663.05, 617.44);
usleep(16484.88);
touchMove(2, 664.08, 613.36);
usleep(16556.46);
touchMove(2, 664.08, 611.33);
usleep(16679.58);
touchUp(2, 663.05, 604.20);
usleep(933728.42);

touchDown(3, 548.09, 995.17);
usleep(17077.62);
touchMove(3, 555.28, 960.54);
usleep(16646.54);
touchMove(3, 558.36, 926.96);
usleep(16571.25);
touchMove(3, 567.59, 891.31);
usleep(16803.21);
touchMove(3, 577.86, 859.74);
usleep(16673.38);
touchMove(3, 590.17, 825.14);
usleep(16607.33);
touchMove(3, 602.50, 792.55);
usleep(16736.62);
touchMove(3, 613.78, 759.98);
usleep(16548.12);
touchMove(3, 622.00, 734.52);
usleep(16668.08);
touchUp(3, 627.12, 714.16);
usleep(283428.67);

touchDown(5, 535.78, 986.01);
usleep(16710.92);
touchMove(5, 543.98, 955.45);
usleep(16583.92);
touchMove(5, 553.22, 893.35);
usleep(16753.62);
touchMove(5, 574.78, 818.02);
usleep(16502.21);
touchMove(5, 601.47, 746.73);
usleep(16683.54);
touchMove(5, 622.00, 695.82);
usleep(16652.71);
touchMove(5, 648.67, 644.91);
usleep(16614.79);
touchUp(5, 684.61, 597.08);
usleep(1000000)				
				
				
else;end;--if ActionFakeUser == "1" then			
end;--Menu.inapp--AddFriend
end;--addfriend()

	
	
	
	
function Noti()
toast("MAX("..IDapp.."/"..count("LIVE")..") ActionFakeUser (Noti) ",15)		
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 
touchDown(1, 562.47, 1287.37);
usleep(66561.58);
touchUp(1, 562.47, 1287.37);
usleep(2485700.04);			
ot("ActionFakeUser.MoreNoti",3);	
for i, v in pairs(findImage(r("ActionFakeUser.MoreNoti"), 1, 0.98, region, false)) do;
touchDown(2, 558.36, 1093.93);
usleep(33434.12);
touchMove(2, 562.47, 1066.43);
usleep(16623.46);
touchMove(2, 562.47, 1044.04);
usleep(16582.25);
touchMove(2, 566.56, 1011.45);
usleep(16549.08);
touchMove(2, 572.73, 975.81);
usleep(16511.71);
touchMove(2, 578.89, 940.19);
usleep(16658.29);
touchMove(2, 586.07, 903.53);
usleep(16681.54);
touchMove(2, 591.20, 870.96);
usleep(16629.21);
touchMove(2, 598.39, 839.39);
usleep(16643.88);
touchMove(2, 604.55, 812.91);
usleep(16750.58);
touchMove(2, 608.65, 785.43);
usleep(16621.67);
touchMove(2, 612.75, 759.98);
usleep(16731.88);
touchMove(2, 615.83, 740.62);
usleep(16694.04);
touchMove(2, 617.89, 724.34);
usleep(16602.75);
touchMove(2, 620.97, 711.11);
usleep(16698.42);
touchMove(2, 622.00, 701.93);
usleep(16696.62);
touchMove(2, 623.02, 694.81);
usleep(16613.00);
touchMove(2, 625.08, 690.73);
usleep(16686.58);
touchMove(2, 627.12, 687.68);
usleep(16751.42);
touchMove(2, 629.17, 684.63);
usleep(16601.00);
touchMove(2, 633.28, 679.54);
usleep(16593.08);
touchUp(2, 634.31, 677.50);
usleep(867246.54);

touchDown(8, 523.46, 1112.25);
usleep(16640.54);
touchMove(8, 523.46, 1096.98);
usleep(16655.58);
touchMove(8, 523.46, 1063.38);
usleep(16752.88);
touchMove(8, 524.48, 1009.42);
usleep(16610.88);
touchMove(8, 533.72, 938.15);
usleep(16703.50);
touchMove(8, 543.98, 870.96);
usleep(16743.96);
touchMove(8, 555.28, 822.09);
usleep(16626.67);
touchMove(8, 566.56, 783.39);
usleep(16677.62);
touchMove(8, 574.78, 753.86);
usleep(16728.71);
touchMove(8, 581.97, 732.48);
usleep(16654.25);
touchMove(8, 588.12, 716.20);
usleep(16679.62);
touchMove(8, 593.25, 703.97);
usleep(16774.96);
touchMove(8, 597.36, 696.84);
usleep(16613.75);
touchMove(8, 599.41, 691.75);
usleep(16648.38);
touchMove(8, 600.44, 690.73);
usleep(16670.46);
touchMove(8, 601.47, 689.72);
usleep(16552.71);
touchUp(8, 604.55, 685.65);
usleep(984169.29);

touchDown(4, 499.86, 1100.04);
usleep(16810.29);
touchMove(4, 506.01, 1070.50);
usleep(16717.12);
touchMove(4, 506.01, 1037.93);
usleep(16619.67);
touchMove(4, 514.22, 988.04);
usleep(16571.12);
touchMove(4, 531.67, 907.60);
usleep(16800.42);
touchMove(4, 555.28, 828.19);
usleep(16546.08);
touchMove(4, 578.89, 757.93);
usleep(16539.00);
touchMove(4, 599.41, 707.04);
usleep(16706.58);
touchMove(4, 614.81, 669.36);
usleep(16602.75);
touchMove(4, 625.08, 643.90);
usleep(16681.46);
touchMove(4, 630.20, 629.65);
usleep(16781.71);
touchMove(4, 634.31, 618.45);
usleep(16560.67);
touchMove(4, 637.39, 611.33);
usleep(16694.21);
touchUp(4, 646.63, 597.08);
usleep(299938.38);

touchDown(7, 494.72, 1115.30);
usleep(16849.12);
touchMove(7, 496.78, 1094.95);
usleep(16591.29);
touchMove(7, 496.78, 1046.08);
usleep(16654.75);
touchMove(7, 507.04, 957.49);
usleep(16721.17);
touchMove(7, 532.70, 857.71);
usleep(16666.79);
touchMove(7, 563.48, 777.28);
usleep(16679.17);
touchMove(7, 582.98, 732.48);
usleep(52474.17);
touchMove(7, 593.25, 708.06);
usleep(14250.92);
touchMove(7, 596.33, 700.91);
usleep(16565.42);
touchMove(7, 598.39, 695.82);
usleep(16640.33);
touchMove(7, 599.41, 694.81);
usleep(50071.62);
touchUp(7, 595.31, 706.02);
usleep(617115.62);

touchDown(3, 515.25, 1106.14);
usleep(16637.25);
touchMove(3, 517.30, 1087.80);
usleep(16781.54);
touchMove(3, 517.30, 1049.13);
usleep(16695.67);
touchMove(3, 525.51, 979.88);
usleep(16620.08);
touchMove(3, 538.86, 908.62);
usleep(16514.79);
touchMove(3, 551.17, 851.60);
usleep(16807.38);
touchMove(3, 563.48, 801.71);
usleep(16660.58);
touchMove(3, 572.73, 770.16);
usleep(16574.62);
touchMove(3, 579.91, 744.70);
usleep(16759.04);
touchMove(3, 587.09, 724.34);
usleep(16764.96);
touchMove(3, 593.25, 707.04);
usleep(16474.21);
touchMove(3, 599.41, 693.79);
usleep(16761.92);
touchMove(3, 605.58, 680.56);
usleep(16738.25);
touchUp(3, 619.94, 654.09);
usleep(249955.21);

touchDown(5, 517.30, 1063.38);
usleep(16625.96);
touchMove(5, 515.25, 1046.08);
usleep(16847.25);
touchMove(5, 515.25, 999.24);
usleep(16618.04);
touchMove(5, 520.37, 910.65);
usleep(16753.88);
touchMove(5, 538.86, 823.10);
usleep(16743.83);
touchMove(5, 565.54, 741.64);
usleep(16477.04);
touchMove(5, 582.98, 688.70);
usleep(16631.08);
touchMove(5, 598.39, 654.09);
usleep(52664.62);
touchMove(5, 614.81, 621.51);
usleep(14205.33);
touchUp(5, 624.05, 601.15);
usleep(250164.08);

touchDown(6, 520.37, 1060.32);
usleep(16448.00);
touchMove(6, 519.36, 1031.81);
usleep(16653.96);
touchMove(6, 520.37, 960.54);
usleep(16710.96);
touchMove(6, 533.72, 876.05);
usleep(16717.79);
touchMove(6, 554.25, 796.62);
usleep(16698.88);
touchMove(6, 573.75, 728.41);
usleep(16693.54);
touchMove(6, 588.12, 691.75);
usleep(16660.29);
touchMove(6, 596.33, 669.36);
usleep(16682.58);
touchMove(6, 601.47, 657.15);
usleep(16726.42);
touchMove(6, 605.58, 651.04);
usleep(16582.58);
touchMove(6, 606.59, 645.93);
usleep(16699.33);
touchMove(6, 607.62, 645.93);
usleep(16681.12);
touchMove(6, 609.67, 645.93);
usleep(33212.46);
touchUp(6, 615.83, 640.84);
usleep(467106.75);

touchDown(9, 513.20, 1044.04);
usleep(16561.79);
touchMove(9, 514.22, 997.20);
usleep(16785.42);
touchMove(9, 522.43, 910.65);
usleep(16687.21);
touchMove(9, 542.96, 826.16);
usleep(16610.79);
touchMove(9, 562.47, 759.98);
usleep(16651.83);
touchMove(9, 576.83, 718.23);
usleep(16761.96);
touchMove(9, 585.04, 691.75);
usleep(16610.08);
touchMove(9, 593.25, 675.47);
usleep(16675.92);
touchMove(9, 599.41, 662.24);
usleep(16695.38);
touchMove(9, 611.73, 644.91);
usleep(16624.29);
touchUp(9, 615.83, 640.84);
usleep(216770.17);

touchDown(1, 499.86, 1096.98);
usleep(16877.17);
touchMove(1, 500.87, 1085.77);
usleep(16645.08);
touchMove(1, 500.87, 1061.34);
usleep(16690.12);
touchMove(1, 500.87, 1015.52);
usleep(16700.96);
touchMove(1, 504.98, 922.87);
usleep(16691.62);
touchMove(1, 527.56, 827.18);
usleep(16845.71);
touchMove(1, 555.28, 745.71);
usleep(16471.71);
touchMove(1, 573.75, 697.86);
usleep(16526.46);
touchMove(1, 589.15, 668.34);
usleep(16655.12);
touchMove(1, 597.36, 651.04);
usleep(16682.67);
touchMove(1, 605.58, 639.83);
usleep(16595.25);
touchMove(1, 614.81, 629.65);
usleep(16554.08);
touchUp(1, 618.92, 625.58);
usleep(250160.04);

touchDown(2, 501.90, 1027.74);
usleep(16913.04);
touchMove(2, 502.93, 995.17);
usleep(16543.29);
touchMove(2, 506.01, 936.12);
usleep(16649.00);
touchMove(2, 523.46, 851.60);
usleep(16764.42);
touchMove(2, 547.06, 779.32);
usleep(16620.58);
touchMove(2, 569.64, 714.16);
usleep(16616.50);
touchMove(2, 586.07, 675.47);
usleep(16756.50);
touchMove(2, 592.23, 656.13);
usleep(16669.92);
touchMove(2, 596.33, 645.93);
usleep(16652.04);
touchMove(2, 599.41, 637.79);
usleep(16652.38);
touchUp(2, 603.52, 633.72);
usleep(719476.38);

touchDown(8, 542.96, 982.95);
usleep(14328.25);
touchMove(8, 546.04, 938.15);
usleep(16606.42);
touchMove(8, 555.28, 888.26);
usleep(16569.21);
touchMove(8, 567.59, 837.35);
usleep(16799.71);
touchMove(8, 577.86, 800.69);
usleep(16645.92);
touchMove(8, 584.01, 778.30);
usleep(16706.62);
touchMove(8, 588.12, 765.07);
usleep(16754.33);
touchMove(8, 590.17, 757.93);
usleep(16614.79);
touchMove(8, 592.23, 752.84);
usleep(16626.50);
touchMove(8, 593.25, 752.84);
usleep(66764.08);
touchMove(8, 593.25, 749.78);
usleep(16651.38);
touchUp(8, 590.17, 747.75);
usleep(584041.46);

touchDown(4, 523.46, 1066.43);
usleep(16714.83);
touchMove(4, 526.54, 1046.08);
usleep(16642.92);
touchMove(4, 526.54, 1007.38);
usleep(17045.21);
touchMove(4, 533.72, 936.12);
usleep(16173.88);
touchMove(4, 549.12, 858.73);
usleep(16484.96);
touchMove(4, 563.48, 805.78);
usleep(16764.21);
touchMove(4, 574.78, 769.14);
usleep(16661.83);
touchMove(4, 582.98, 745.71);
usleep(16837.92);
touchMove(4, 589.15, 730.45);
usleep(16511.71);
touchMove(4, 593.25, 721.29);
usleep(16511.04);
touchMove(4, 597.36, 715.18);
usleep(16663.75);
touchMove(4, 600.44, 708.06);
usleep(16713.62);
touchUp(4, 606.59, 698.88);
usleep(1000000);		
		
end;--Menu.inapp		
end;--ActionFakeUser.MoreNoti	
end;--Noti()	
		

function lastActionFakeUser()	
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000) 	
touchDown(6, 64.66, 1270.06);
usleep(99952.17);
touchUp(6, 64.66, 1270.06);
usleep(150236.67);

touchDown(6, 67.74, 1278.21);
usleep(66555.25);
touchUp(6, 67.74, 1278.21);
usleep(1351273.58);
end;--Menu.inapp
end;--lastActionFakeUser()



--============================================================================================

function ActionFakeUser()
appKill(appZ);usleep(500000);
openURL("fb://feed");usleep(5000000);
ot("Menu.inapp",5)
Newsfeed();usleep(100000);	
addfriend();usleep(100000);	
Noti();usleep(100000);	
lastActionFakeUser();usleep(100000);		
	end; 

local f = io.open(r(".../.../temmp/A10",1), "rb"); local A10 = f:read("*all"); f:close(); 
if A10 == "0" then
	else;	
for ActionFakeUserLoop = 1, A10 do
for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)	
toast("MAX("..IDapp.."/"..count("LIVE")..") ActionFakeUser "..ActionFakeUserLoop.."/"..A10,5);end;--Menu.inapp
ActionFakeUser()
end;
end;

end;--function A10XX()


function SubfunctionAll()
 A6XX();usleep(300000);	
 A7XX();usleep(300000);		
 A8XX();usleep(300000);	
 A9XX();usleep(300000);	
 A10XX();usleep(300000);	
end;--function SubfunctionAll()


--=========================================================================================================
--=========================================================================================================
--=========================================================================================================
--=========================================================================================================

function Mainfunction711();
	


local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();  	


function rU()

ranCheck = math.random(1,c0unt(r(".../.../temmp/AddFriendUID.txt",1)))	
local f = io.open(r(".../.../temmp/rI",1), "w");f:write(ranCheck);f:close()	
local f = io.open(r(".../.../temmp/AddFriendUID.txt",1), "rb"); local content = f:read("*all"); f:close(); 	
local LineInUIDfile = ranCheck  -----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
copyText(LineX)	
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
			
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	local Code2FAX = UID_PASS[4]
	copyText(UIDX); --toast(UIDX)
				
		end;--end call value	
					
end;--rU()

	



function A6X()
openURL("fb://profile");usleep(200000);
openURL("fb://feed");usleep(200000);
ot("Menu.inapp",10);for i, v in pairs(findImage(r("Menu.inapp"), 1, 0.98, region, false)) do;
local f = io.open(r(".../.../temmp/A2",1), "rb"); local A2 = f:read("*all"); f:close();
for lppxA2 = 1, tonumber(A2) do
rU();usleep(100000)	
local f = io.open(r(".../.../temmp/rI",1), "rb"); local rI = f:read("*all"); f:close();
openURL("fb://profile/"..clipText());usleep(2000000);
toast("MAX("..IDapp.."/"..count("LIVE")..") AddFriendUID ("..lppxA2.."/"..tonumber(A2)..")\n     "..rI.." : "..clipText(),15)			
ot("AddFriend.more",5);usleep(1000000);for i, v in pairs(findImage(r("AddFriend.more"), 1, 0.98, region, false)) do;

				for lppxt = 1,3 do
for i, v in pairs(findImage(r("AddFriend.AddFriend"), 1, 0.98, region, false)) do;				
touchDown(4, 358.21, 876.05);
usleep(1083523.96);
touchUp(4, 358.21, 876.05);
usleep(1000000);
end;--AddFriend.AddFriend
					end;--for lppxt = 1,3 do
				
ot("AddFriend.AddFriend",3) ;for i, v in pairs(findImage(r("AddFriend.AddFriend"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(5,30) , v[2]+math.random(1,15));usleep(500000); end;--AddFriend.AddFriend
 for Lppx = 1,3 do;scrollup();usleep(100000);end;
									
end;--AddFriend.more
		end;--for lppxA7 = 1, tonumber(A7) do
		--ConfirmFriend();
		
		

	
openURL("fb://feed");usleep(3000000);	
SubfunctionAll();usleep(300000);	
end;--Menu.inapp
end;--A6X()


--===========================================================================================
local f = io.open(r(".../.../temmp/A2",1), "rb"); local A2 = f:read("*all"); f:close();	

if A2 == "0" then
   else
appKill(appZ);usleep(500000);
openURL("fb://feed");usleep(1000000);
	A6X();usleep(100000);
end;--if A7 == "0" then

	
end;--function Mainfunction711();


--=====================================================================================================================
--=====================================================================================================================
function BRun()
copyText("FrankyNouva")
FrankyNouvaUpdate("ky")--OK/NO
if clipText() == "OK" then
		
local f = io.open(r(".../.../temmp/appX.txt",1), "rb"); local appX = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/appY.txt",1), "rb"); local appY = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/c",1), "rb"); local c = f:read("*all"); f:close();
	
if c == "NO" then;else;CheckLiveAll2();usleep(500000);end;

for IDapp = appX, appY do   --count("LIVE") do
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/c",1), "w");f:write("OK");f:close() 	
local f = io.open(r(".../.../temmp/IDapp.txt",1), "w");f:write(IDapp);f:close() 	
AutoLogin();usleep(500000);
--checklogin();usleep(300000);
--checkliveX();usleep(300000);
--toast("wait popup");
--nomesspopup();usleep(300000);
appRun(appZ);usleep(100000);		
Mainfunction711();usleep(300000);	
	end;--lpp	
			else;end;
end;--function BRun()
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
local f = io.open(r(".../BZ",1), "rb"); local BZ = f:read("*all"); f:close(); 
if BZ == "NO" then;BRun();usleep(300000);else;end;