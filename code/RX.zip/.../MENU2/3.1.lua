function FrankyNouva(namecall,input1,input2,input3,input4,input5,input6,input7);
	namecall= tostring(namecall)
	input1= tostring(input1)
	input2= tostring(input2)
	input3= tostring(input3)
	input4= tostring(input4)
	input5= tostring(input5)
	input6= tostring(input6)
	input6= tostring(input7)
     local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/ate", "w");f:write(namecall);f:close();
	if input1 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write(tostring(input1));f:close(); end
	if input2 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write(tostring(input2));f:close(); end
	if input3 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write(tostring(input3));f:close(); end
	if input4 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write(tostring(input4));f:close(); end
	if input5 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write(tostring(input5));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write(tostring(input6));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write(tostring(input6));f:close(); end
if string.find(namecall, "fms") then namecall = "fms" else;end
if string.find(namecall, "app") then namecall = "app" else;end
	usleep(100000)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(""..crc..".../.../"..namecall..".ate")
	usleep(100000)
end;
function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/images/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function ot(name,input)
local now = os.time();local locations;repeat;local locations = findImage(r(name), 1, 0.98, region, false);until(#locations > 0) or os.time()-now>=tonumber(input);usleep(300000); 
end;
function FrankyN0uva(name)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(crc..name..".ate")	
		usleep(100000);
	return
end;
--================================================================
local date = os.date("%d/%m/%Y");
local label = {type=CONTROLLER_TYPE.LABEL, text="⭕MAX2020(Premium)           FrankyNouva\n                                                      0933.998.772"}
local nameInput = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="📛 CẢNH BÁO : Hãy đọc thật KỸ hướng dẫn !"}
local btn = {type=CONTROLLER_TYPE.BUTTON, title="🔙   "..date, color=0xFF5733, width=0.5, flag=20, collectInputs=true}
local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="1.UpStory(photo)", color=0x71C69E, width=1.0, flag=1, collectInputs=false}
local btn2 = {type=CONTROLLER_TYPE.BUTTON, title="2.UpStory(video)", color=0x71C69E, width=1.0, flag=2, collectInputs=false}
local btn30 = {type=CONTROLLER_TYPE.BUTTON, title="THOÁT", color=0xFF5733, width=1.0, flag=30, collectInputs=false}
local controls = {label, nameInput, btn, btn1, btn2, btn30}
local result = dialog(controls, orientations);
if (result == 20) then
FrankyN0uva(rx(".../m",1))
elseif (result == 1) then
FrankyN0uva(rx(".../MENU3/3.1.1",1))		
elseif (result == 2) then
FrankyN0uva(rx(".../MENU3/3.2.1",1))			
elseif (result == 30) then		
		else
				end	