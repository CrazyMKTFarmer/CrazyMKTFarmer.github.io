function FrankyNouva(namecall,input1,input2,input3,input4,input5,input6,input7);
	namecall= tostring(namecall)
	input1= tostring(input1)
	input2= tostring(input2)
	input3= tostring(input3)
	input4= tostring(input4)
	input5= tostring(input5)
	input6= tostring(input6)
	input6= tostring(input7)
     local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/ate", "w");f:write(namecall);f:close();
	if input1 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write(tostring(input1));f:close(); end
	if input2 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write(tostring(input2));f:close(); end
	if input3 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write(tostring(input3));f:close(); end
	if input4 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write(tostring(input4));f:close(); end
	if input5 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write(tostring(input5));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write(tostring(input6));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write(tostring(input6));f:close(); end
if string.find(namecall, "fms") then namecall = "fms" else;end
if string.find(namecall, "app") then namecall = "app" else;end
	usleep(100000)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(""..crc..".../.../"..namecall..".ate")
	usleep(100000)
end;
function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/images/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function ot(name,input)
local now = os.time();local locations;repeat;local locations = findImage(r(name), 1, 0.98, region, false);until(#locations > 0) or os.time()-now>=tonumber(input);usleep(300000); 
end;
function FrankyN0uva(name)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(crc..name..".ate")	
		usleep(100000);
	return
end;
--================================================================
stringX = [[
1.Hạn chế để máy cạn pin, sập nguồn.
2.Không tự ý xóa app, nâng cấp iOS.
3.Không chạy lại Ctrình, khôi phục gốc.
4.Không thay đổi cỡ chữ, ngôn ngữ máy.
5.Không dc bật thông báo cho mọi app.
6.Không dc can thiệp hệ thống, Cydia.
7.Dữ liệu nhập ĐÚNG-ĐỦ-ĐỈNH như HD.
8.Tuân thủ về ngưỡng và tần suất(dc HD).
9.KQ là sp tư duy, quá trình, Tool chỉ là c.cụ.
10.Mọi VPhạm sẽ không BH,cấm Vĩnh Viễn.]]
local date = os.date("%d/%m/%Y");
local label = {type=CONTROLLER_TYPE.LABEL, text="⭕MAX2020(Premium)           FrankyNouva\n                                                      0933.998.772\n"..stringX}
local nameInput = {type=CONTROLLER_TYPE.INPUT, title="\nKÍCH HOẠT KEY:", key="Name", value="Soạn "..getSN().." gửi Zalo 0933.998.772"}
local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="TÔI ĐỒNG Ý", color=0xFF5733, width=1.0, flag=1, collectInputs=false}
local btn2 = {type=CONTROLLER_TYPE.BUTTON, title="CẬP NHẬT", color=0xFF5733, width=1.0, flag=2, collectInputs=false}
local controls = {label, nameInput, btn1, btn2}
local result = dialog(controls, orientations);
if (result == 1) then
		toast("Chân thành cảm ơn bạn !")
		copyText(""..getSN().."-MAX2020Premium"); 
elseif (result == 2) then	
FrankyN0uva(rx(".../UDT",1))
		else
				end