function FrankyNouva(namecall,input1,input2,input3,input4,input5,input6,input7);
	namecall= tostring(namecall)
	input1= tostring(input1)
	input2= tostring(input2)
	input3= tostring(input3)
	input4= tostring(input4)
	input5= tostring(input5)
	input6= tostring(input6)
	input6= tostring(input7)
     local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/ate", "w");f:write(namecall);f:close();
	if input1 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write(tostring(input1));f:close(); end
	if input2 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write(tostring(input2));f:close(); end
	if input3 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write(tostring(input3));f:close(); end
	if input4 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write(tostring(input4));f:close(); end
	if input5 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write(tostring(input5));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write(tostring(input6));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write(tostring(input6));f:close(); end
if string.find(namecall, "fms") then namecall = "fms" else;end
if string.find(namecall, "app") then namecall = "app" else;end
	usleep(100000)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(""..crc..".../.../"..namecall..".ate")
	usleep(100000)
end;
function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/images/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function ot(name,input)
local now = os.time();local locations;repeat;local locations = findImage(r(name), 1, 0.98, region, false);until(#locations > 0) or os.time()-now>=tonumber(input);usleep(300000); 
end;
function FrankyN0uva(name)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(crc..name..".ate")	
		usleep(100000);
	return
end;
--================================================================
function CheckLive()
local f = io.open(r(".../.../temmp/Bundleapp.txt",1), "w");f:write("com.Facebook.FrankyNouva1.U2D4TGM68X");f:close() 
local f = io.open(r(".../.../temmp/LIVE.txt",1), "w");f:write("");f:close() 
local f = io.open(r(".../.../temmp/GONE.txt",1), "w");f:write("");f:close() 
for CheckX = 1, count("ACC") do
local f = io.open(r(".../.../temmp/CheckX.txt",1), "w");f:write(CheckX);f:close() 
local f = io.open(r(".../.../temmp/ACC.txt",1), "rb"); local content = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  
local LineInUIDfile = tonumber(CheckX)-----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	local Code2FAX = UID_PASS[4]
--function CheckLive(uid)
	https = require("ssl.https")
	body, code, headers, status = https.request('https://graph.facebook.com/'..UIDX..'/picture')
		
		if headers == nil then test = "NOT image/gif"; toast("Error check, UID to live, check later",5)  --fix header-recheck
			log(""..UIDX.." Error check, UID to LIVE, check later")
		else
			test = headers["content-type"]
		      end;		
	--test = headers["content-type"]
	if (test == "image/gif") then
		--vibrate();
			--perx = CheckX/count("UIDACC")*100
			perx = (math.floor(CheckX/count("ACC")*100 * 100)/100)
		    pery = (math.floor(count("GONE")/count("ACC")*100 * 100)/100)
			--toast(perx)
		toast(""..perx.."%  ❌ UID"..CheckX.." ("..count("LIVE").."/"..count("GONE").."/"..count("ACC")..") ⛔️ "..pery.."%\n\nĐang CheckLive, vui lòng:\n1.Không dừng chạy lúc này!\n2.Không thao tác gì trên máy !\n\nLƯU Ý: CheckLive rất nhanh, 1.000 acc/3p !")
			
			local f = io.open(r(".../.../temmp/GONE.txt",1), "rb"); local GONE = f:read("*all"); f:close();
			--local f = io.open(r("../.../temmp/LIVE.txt",1), "rb"); local LIVE = f:read("*all"); f:close();
			  if GONE == "" then
	          local f = io.open(r(".../.../temmp/GONE.txt",1), "w");f:write(LineX);f:close() 
	          else
			  local f = io.open(r(".../.../temmp/GONE.txt",1), "a+");f:write("\n"..LineX.."");f:close() 
	          end;
			
		--return 1
			
	else

			perx = (math.floor(CheckX/count("ACC")*100 * 100)/100)
            pery = (math.floor(count("GONE")/count("ACC")*100 * 100)/100)
		toast(""..perx.."%  ✅ UID"..CheckX.." ("..count("LIVE").."/"..count("GONE").."/"..count("ACC")..") ⛔️ "..pery.."%\n\nĐang CheckLive, vui lòng:\n1.Không dừng chạy lúc này!\n2.Không thao tác gì trên máy !\n\nLƯU Ý: CheckLive rất nhanh, 1.000 acc/3p !")
			
			--local f = io.open(r(".../.../temmp/GONE.txt",1), "rb"); local GONE = f:read("*all"); f:close();
			local f = io.open(r(".../.../temmp/LIVE.txt",1), "rb"); local LIVE = f:read("*all"); f:close();			
			  if LIVE == "" then
	          local f = io.open(r(".../.../temmp/LIVE.txt",1), "w");f:write(LineX);f:close() 
	          else
			  local f = io.open(r(".../.../temmp/LIVE.txt",1), "a+");f:write("\n"..LineX.."");f:close() 
	          end;		
	end
--end;--function
		end;--call value
	--usleep(1000000)
	end;--lpppx
--backup and creat
local date = os.date("%d_%m_%Y___%H_%M_%S");
local f = io.open(r(".../.../temmp/ACC.txt",1), "rb"); local ACCbackup = f:read("*all"); f:close(); 
local f = io.open(r(".../.../Backup/ACC_"..date..".txt",1), "w");f:write(ACCbackup);f:close()   
usleep(10000);
local f = io.open(r(".../.../temmp/LIVE.txt",1), "rb"); local LIVE = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/GONE.txt",1), "rb"); local GONE = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/ACC.txt",1), "w");f:write(""..LIVE.."\n"..GONE.."");f:close() 
local f = io.open(r("MAX2020/1.ACC/ACC.txt",1), "w");f:write(""..LIVE.."\n"..GONE.."");f:close() 
local date = os.date("%d/%m/%Y");	
local f = io.open(r(".../.../temmp/d",1), "w");f:write(date);f:close() 	
playAudio(r("Run.m4r",1), 2);
toast("CheckLive Done ! "..count("LIVE").."/"..count("GONE").."/"..count("ACC").."",15)
end;
local date = os.date("%d/%m/%Y");
local label = {type=CONTROLLER_TYPE.LABEL, text="⭕MAX2020(Premium)           FrankyNouva\n                                                      0933.998.772"}
local btn = {type=CONTROLLER_TYPE.BUTTON, title="🔙   "..date, color=0xFF5733, width=0.5, flag=20, collectInputs=true}
local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="Start", color=0x71C69E, width=1.0, flag=1, collectInputs=true}
local nameInput = {type=CONTROLLER_TYPE.INPUT, title="✅ CheckLive:", key="Name", value="CheckLive file ACC.txt, đang có "..count("ACC").." acc"}
local btn30 = {type=CONTROLLER_TYPE.BUTTON, title="THOÁT", color=0xFF5733, width=1.0, flag=30, collectInputs=true}
local controls = {label, btn,btn1, nameInput, btn30}
local result = dialog(controls, orientations);
if (result == 20) then
FrankyN0uva(rx(".../MENU2/1.1",1))			
elseif (result == 1) then
CheckLive()
FrankyN0uva(rx(".../MENU3/1.2.1",1))	
	else
	end;