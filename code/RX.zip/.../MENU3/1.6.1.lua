function FrankyNouva(namecall,input1,input2,input3,input4,input5,input6,input7);
	namecall= tostring(namecall)
	input1= tostring(input1)
	input2= tostring(input2)
	input3= tostring(input3)
	input4= tostring(input4)
	input5= tostring(input5)
	input6= tostring(input6)
	input6= tostring(input7)
     local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/ate", "w");f:write(namecall);f:close();
	if input1 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write(tostring(input1));f:close(); end
	if input2 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write(tostring(input2));f:close(); end
	if input3 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write(tostring(input3));f:close(); end
	if input4 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write(tostring(input4));f:close(); end
	if input5 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write(tostring(input5));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write(tostring(input6));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write(tostring(input6));f:close(); end
if string.find(namecall, "fms") then namecall = "fms" else;end
if string.find(namecall, "app") then namecall = "app" else;end
	usleep(100000)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(""..crc..".../.../"..namecall..".ate")
	usleep(100000)
end;
function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/images/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function ot(name,input)
local now = os.time();local locations;repeat;local locations = findImage(r(name), 1, 0.98, region, false);until(#locations > 0) or os.time()-now>=tonumber(input);usleep(300000); 
end;
function FrankyN0uva(name)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(crc..name..".ate")	
		usleep(100000);
	return
end;


function ResetApp()
trx = [[                      LƯU Ý QUAN TRỌNG

Vui lòng không quay video tool chạy để SHOW/SHARE/KHOE nơi khác (cả inbox BẠN BÈ) tránh bị reup/nhại/cắp hoặc fb fix (RẤT NHANH) sẽ ẢNH HƯỞNG đến quyền lợi chung của anh em khác! Mọi TH VI PHẠM sẽ ngắt KEY và cấm VĨNH VIỄN mà không cần bất kì thông báo hay trách nhiệm nào. Trường hợp show trực tiếp tận mắt cho người quen ! HOA HỒNG 20% khi giới thiệu thành công !

MỘT SỐ LƯU Ý CÂN NHẮC:
- Nuôi acc cần kinh nghiệm, test nhiều.
- Nuôi ngây, nuôi ngô, k đổ do, thì, là, bị, tại.
- Acc non không dc ShareLive/AddFr/JoinG.
- Tool chỉ bổ trợ, hiệu quả ở tư duy, KN.
- Trọng yếu nuôi: KN,%trùng,ngưỡng,tần suất.
- Cập nhật KN: GroupFB/Zalo, Follow cao thủ.
- Nuôi hướng SEO, MKT thay vì SP4M thuần.

                                                Franky Nouva
                                          Chân thành cảm ơn !
]]
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("NO");file:close()
FrankyN0uva(r(".../.../ClearRam",1));
io.popen('activator send libactivator.profile.Defaullt')
appRun("com.tigisoftware.ADManager");
ot("Reset.max2020",5);for i, v in pairs(findImage(r("Reset.max2020"), 1, 0.98, region, false)) do;
tap(177.57, 168.44);usleep(200000);
		tap(100, 875);usleep(200000) 

--ot("Reset.cancel",5) for i, v in pairs(findImage(r("Reset.cancel"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
tap(math.random(75,650), 1150);     usleep(10000); 
toast("\n\n"..trx,6);
toast("\n\n"..trx,6)
toast("⭕️ MAX2020Pre                  "..getSN(),6);
toast("⭕️ MAX2020Pre                  "..getSN(),6);
keyDown(KEY_TYPE.HOME_BUTTON);
usleep(186936.67);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(163298.17);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(2000000);
for i, v in pairs(findImage(r("fixFacetimeAlert"), 1, 0.98, region, false)) do;
tap(515, 760);usleep(500000);end;--fixFacetimeAlert	
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("OK");file:close()				
end;--Reset.Applications.png
io.popen('activator send libactivator.profile.Default')
appKill("com.tigisoftware.ADManager");usleep(500000);  
end;--ResetApp()
--================================================================
function LogIn()
local f = io.open(r(".../.../temmp/IDapp.txt",1), "w");f:write(clipText());f:close() 
local f = io.open(r(".../.../temmp/Bundleapp.txt",1), "w");f:write("com.facebook.FrankyNouva");f:close() 
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local content = f:read("*all"); f:close();  
file = io.open(r(".../.../temmp/login.txt",1), "w");file:write("NOT");file:close()
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  
file = io.open(r(".../.../temmp/login.txt",1), "w");file:write("NOT");file:close()	
local f = io.open(r(".../.../temmp/Bundleapp.txt",1), "rb"); local Bundleapp = f:read("*all"); f:close();
local file = r(".../.../temmp/LIVE.txt",1)
local f = io.open(file, "rb"); local content = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  
local LineInUIDfile = tonumber(IDapp)-----none of set value--Get line
local ColumeX1 = 1 -----none of set value--get colummn 1
local ColumeX2 = 2 -----none of set value--get colummn 2
local ColumeX3 = 3 -----none of set value--get colummn 3
local ColumeX4 = 4 -----none of set value--get colummn 4
--usleep(500000); --Important fix
function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end
local xxx=split(content, '\n')
local LineX = (xxx[LineInUIDfile])----local a = xxx[2]
function split(s, d)
    rtz = {};
    for m in (s..d):gmatch("(.-)"..d) do
        table.insert(rtz, m);
    end
    return rtz;
end
local a = LineX -----------------local a = xxx[2]
for i,v in pairs(split(a, '\n')) do
	local line = v
	local UID_PASS = split(v, '|')
--toast(''..UID_PASS[ColumeX1]..'-'..UID_PASS[ColumeX2]..'-'..UID_PASS[ColumeX3]..'', 2)
	local UIDX = UID_PASS[1]
	local PassX = UID_PASS[2]
	
	for i = 3,6 do
		if UID_PASS[i] == nil then
		UID_PASS[i] = "Không có 2 FA hoặc 2FA sai"; --toast(UID_PASS[i])
		Code2FAX = "Không có 2 FA hoặc 2FA sai"	
			break
			elseif string.len(UID_PASS[i]) == 32 then
			Code2FAX = UID_PASS[i]; --toast(UID_PASS[i])
			break
		else    --if string.len(UID_PASS[i])
		Code2FAX = "Không có 2 FA hoặc 2FA sai"
	end;
	end;       

--IMPORTANT !!!!!!!!!!!!!		
ResetApp();usleep(300000);
toast("Login M"..IDapp.."/"..count("LIVE").."",10)	
local f = io.open(r(".../.../temmp/appZ",1), "rb"); local appZ = f:read("*all"); f:close();  	
appRun(appZ);usleep(10000000);	
--ip();
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 	
local now = os.time();local locations;repeat;local locations = findImage(r("Autologin.password"), 1, 0.98, region, false);
		until(#locations > 0) or os.time()-now>=10;--usleep(300000); 		
for i, v in pairs(findImage(r("Autologin.password"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,420), v[2]-math.random(60,100));    usleep(math.random(500000,1200000));         
		inputText("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b"); usleep(math.random(100000,300000));	
FrankyNouva("input",UIDX);usleep(math.random(500000,1200000));
		for i, v in pairs(findImage(r("Autologin.password"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,420), v[2]-math.random(1,20));     usleep(math.random(500000,1200000));          
FrankyNouva("input",PassX);usleep(math.random(500000,1200000));			
for i, v in pairs(findImage(r("Autologin.login"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,200), v[2]-math.random(1,20));    usleep(math.random(500000,1200000));  
					end;--Autologin.login.png			
local now = os.time();local locations;repeat;local locations = findImage(r("Autologin.okrequired2FA"), 1, 0.98, region, false);
		until(#locations > 0) or os.time()-now>=10;--usleep(300000); 
for i, v in pairs(findImage(r("Autologin.required2FA"), 1, 0.98, region, false)) do;				
for i, v in pairs(findImage(r("Autologin.okrequired2FA"), 1, 0.98, region, false)) do;
		tap(v[1], v[2]);     usleep(500000);         
for i, v in pairs(findImage(r("Autologin.inputCode"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,100), v[2]-math.random(1,20));    usleep(math.random(500000,1200000));
copyText(Code2FAX)					
							usleep(math.random(1500000,2500000));
if Code2FAX == "Không có 2 FA hoặc 2FA sai" then toast(Code2FAX)					
							else						
FrankyNouva("Get2FA",Code2FAX);						
usleep(2000000);													
							end;							
appRun(Bundleapp);	
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();  
toast("Login M"..IDapp.."/"..count("LIVE").."",15)	
ot("Autologin.resendcode",5) ;						
inputText("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");usleep(300000);								
FrankyNouva("input",clipText());usleep(math.random(500000,1200000));						
for i, v in pairs(findImage(r("Autologin.resendcode"), 1, 0.98, region, false)) do;
--log("relog "..appn.."/"..rtes.."");	
							
if Code2FAX == "Không có 2 FA hoặc 2FA sai" then toast(Code2FAX)					
							else
for i, v in pairs(findImage(r("Autologin.login"), 1, 0.98, region, false)) do;
tap(v[1]+math.random(1,100), v[2]-math.random(1,20));    usleep(math.random(5000000,8000000));				
		        end;--Autologin.login.png	
								
	function nomesspopup()
ot("fix.NomessPopup",1)
for i, v in pairs(findImage(r("fix.NomessPopup"), 1, 0.98, region, false)) do;
 tap(v[1], v[2]); usleep(math.random(300000,800000));end;--fix.NomessPopup2.png	
for i, v in pairs(findImage(r("fix.NomessPopup2"), 1, 0.98, region, false)) do;
 tap(v[1], v[2]); usleep(math.random(300000,800000));
	end;--fix.NomessPopup2.png
	end;
	nomesspopup()							
							end;--end check if Code2FAX = "Không có 2 FA hoặc 2FA sai"							
                end;--Autologin.resendcode.png				
			    end;--Autologin.inputCode.png
				end;--Autologin.okrequired2FA.png
			    end;--Autologin.required2FA.png
				--usleep(50000000);
				
--============================  
for i, v in pairs(findImage(r("Autologin.findconnect"), 1, 0.98, region, false)) do;
for i, v in pairs(findImage(r("Autologin.OKfindconnect"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.OKfindconnect.png 
end;--Autologin.findconnect.png
					
					
for i, v in pairs(findImage(r("Autologin.allow"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.allow.png  						
for i, v in pairs(findImage(r("Autologin.OkCamera"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000)); ;end;--Autologin.OkCamera.png									
for i, v in pairs(findImage(r("Autologin.savelogin"), 1, 0.98, region, false)) do;
tap(math.random(410,650), v[2]-math.random(1,10)); toast("saved acc"); usleep(math.random(300000,800000));end;--Autologin.savelogin.png
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png	
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png
for i, v in pairs(findImage(r("Autologin.skip"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,5), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--Autologin.skip.png	
for i, v in pairs(findImage(r("addnumber.notnow"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,50), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--addnumber.notnow.png	
		
--============================					
for i, v in pairs(findImage(r("logoHome"), 1, 0.98, region, false)) do;
toast("Login M"..IDapp.."/"..count("LIVE").." OK"); --log("ACC OK "..appn.."/"..rtes.."");
for i, v in pairs(findImage(r("fixNewfeature"), 1, 0.98, region, false)) do;
 tap(v[1]+math.random(1,50), v[2]+math.random(1,5)); usleep(math.random(300000,800000));end;--fixNewfeature.png					
				;end;--logoHome.png
			
--============================						
		end;--Autologin.password--PASS		
		end;--Autologin.password--UIDX		
		
		
		end;--call value
	
	function nomesspopup()
ot("fix.NomessPopup",2) 											
for i, v in pairs(findImage(r("fix.NomessPopup"), 1, 0.98, region, false)) do;
 tap(v[1], v[2]); usleep(math.random(300000,800000));end;--fix.NomessPopup2.png	
for i, v in pairs(findImage(r("fix.NomessPopup2"), 1, 0.98, region, false)) do;
 tap(v[1], v[2]); usleep(math.random(300000,800000));
	end;--fix.NomessPopup2.png
	end;
	--nomesspopup()

end;

local date = os.date("%d/%m/%Y");
local label = {type=CONTROLLER_TYPE.LABEL, text="⭕MAX2020(Premium)           FrankyNouva\n                                                      0933.998.772"}
local btn = {type=CONTROLLER_TYPE.BUTTON, title="🔙   "..date, color=0xFF5733, width=0.5, flag=20, collectInputs=true}
local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="Start", color=0x71C69E, width=1.0, flag=1, collectInputs=true}
local nameInput = {type=CONTROLLER_TYPE.INPUT, title="✅LoginAcc(X):", key="Name", value="Bạn Muốn login vào acc số: 1"}
local btn30 = {type=CONTROLLER_TYPE.BUTTON, title="THOÁT", color=0xFF5733, width=1.0, flag=30, collectInputs=true}
local controls = {label, btn, btn1, nameInput, btn30}
local result = dialog(controls, orientations);
if (result == 20) then
FrankyN0uva(rx(".../MENU2/1.1",1))		
elseif (result == 1) then
if string.match(nameInput.value,"%d+") == nil or tonumber(string.match(nameInput.value,"%d+")) == 0 then
toast("Thánh vui lòng nhập đúng thông số hộ em !",10)
FrankyN0uva(rx(".../MENU3/1.6.1",1))	
elseif tonumber(string.match(nameInput.value,"%d+")) > count("ACC")	then
toast("Thánh có "..count("ACC").." acc thôi, nhập chi số "..tonumber(string.match(nameInput.value,"%d+")).." =)))",10)
FrankyN0uva(rx(".../MENU3/1.6.1",1))			
		else
toast("Bạn đang chọn Login vào Acc số ("..string.match(nameInput.value,"%d+")..")",5)
nameInput.value = string.match(nameInput.value,"%d+")
copyText(nameInput.value)			
LogIn()	
		end;
elseif (result == 30) then	
	else
	end;
