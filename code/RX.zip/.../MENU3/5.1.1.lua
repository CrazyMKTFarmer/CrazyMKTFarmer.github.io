function FrankyNouva(namecall,input1,input2,input3,input4,input5,input6,input7);
	namecall= tostring(namecall)
	input1= tostring(input1)
	input2= tostring(input2)
	input3= tostring(input3)
	input4= tostring(input4)
	input5= tostring(input5)
	input6= tostring(input6)
	input6= tostring(input7)
     local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/ate", "w");f:write(namecall);f:close();
	if input1 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input1", "w");f:write(tostring(input1));f:close(); end
	if input2 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input2", "w");f:write(tostring(input2));f:close(); end
	if input3 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input3", "w");f:write(tostring(input3));f:close(); end
	if input4 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input4", "w");f:write(tostring(input4));f:close(); end
	if input5 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input5", "w");f:write(tostring(input5));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input6", "w");f:write(tostring(input6));f:close(); end
	if input6 == nil then local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write("0");f:close();
		else local f = io.open("/var/mobile/Library/AutoTouch/Scripts/.../temmp/input7", "w");f:write(tostring(input6));f:close(); end
if string.find(namecall, "fms") then namecall = "fms" else;end
if string.find(namecall, "app") then namecall = "app" else;end
	usleep(100000)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(""..crc..".../.../"..namecall..".ate")
	usleep(100000)
end;
function fky()
for rt = 1, 10 do
tap(math.random(130,600),math.random(930,1200));usleep(5000);
end; inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(300000);inputText("😊 ");usleep(1000000);
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/images/fky1.png", 1, 0.98, region, false)) do;
inputText("\b\b\b\b\b\b\b\b\b\b\b"); usleep(500000);tap(v[1], v[2]);  usleep(500000); 	
touchDown(2, v[1], v[2]);
usleep(831971.67);
touchUp(2, v[1], v[2]);
usleep(1000000)			
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky2.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky2.png 	
for i, v in pairs(findImage("/var/mobile/Library/AutoTouch/Scripts/imagesss/fky3.png", 1, 0.98, region, false)) do;
tap(v[1], v[2]);  usleep(1500000);         end;---fky3.png		
	end;---fky1.png 
	usleep(500000); 
end;
function r(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == nil then
	root = "/var/mobile/Library/AutoTouch/Scripts/imagesss/"..name..".png"
	elseif input1 == 2 then
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
	else
		root = "/var/mobile/Library/AutoTouch/Scripts/"..name..""
		end;--if name == nil then
	return root
	end;
function rx(name,input1)
	if name == nil and input1 == nil then
		root = "/var/mobile/Library/AutoTouch/Scripts/"
	elseif input1 == 1 then
		root = name
		else;end;
	return root
	end;
function count(name)
local f=io.open("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt","r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines("/var/mobile/Library/AutoTouch/Scripts/.../.../temmp/"..name..".txt") do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function c0unt(file)
local f=io.open(file,"r");
if f~=nil then io.close(f) 
 sodong = 0
  for i in io.lines(file) do
    sodong = sodong + 1
  end 
--toast(sodong)
return sodong
else 
return toast("file không tồn tại") end 
end
function ot(name,input)
local now = os.time();local locations;repeat;local locations = findImage(r(name), 1, 0.98, region, false);until(#locations > 0) or os.time()-now>=tonumber(input);usleep(300000); 
end;
function FrankyN0uva(name)
	cx = "8080/control/start_playing?"
	crc = "http://127.0.0.1:"..cx.."path=/"
local http = require("socket.http")	
local body, code = http.request(crc..name..".ate")	
		usleep(100000);
	return
end;


function ResetApp()
trx = [[                      LƯU Ý QUAN TRỌNG

Vui lòng không quay video tool chạy để SHOW/SHARE/KHOE nơi khác (cả inbox BẠN BÈ) tránh bị reup/nhại/cắp hoặc fb fix (RẤT NHANH) sẽ ẢNH HƯỞNG đến quyền lợi chung của anh em khác! Mọi TH VI PHẠM sẽ ngắt KEY và cấm VĨNH VIỄN mà không cần bất kì thông báo hay trách nhiệm nào. Trường hợp show trực tiếp tận mắt cho người quen ! HOA HỒNG 20% khi giới thiệu thành công !

MỘT SỐ LƯU Ý CÂN NHẮC:
- Nuôi acc cần kinh nghiệm, test nhiều.
- Nuôi ngây, nuôi ngô, k đổ do, thì, là, bị, tại.
- Acc non không dc ShareLive/AddFr/JoinG.
- Tool chỉ bổ trợ, hiệu quả ở tư duy, KN.
- Trọng yếu nuôi: KN,%trùng,ngưỡng,tần suất.
- Cập nhật KN: GroupFB/Zalo, Follow cao thủ.
- Nuôi hướng SEO, MKT thay vì SP4M thuần.

                                                Franky Nouva
                                          Chân thành cảm ơn !
]]
io.popen('activator send switch-off.com.a3tweaks.switch.wifi')
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close(); 
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("NO");file:close()
FrankyN0uva(r(".../.../ClearRam",1));
io.popen('activator send libactivator.profile.Defaullt')
appRun("com.tigisoftware.ADManager");
ot("Reset.max2020",5);for i, v in pairs(findImage(r("Reset.max2020"), 1, 0.98, region, false)) do;
tap(177.57, 168.44);usleep(200000);
		tap(100, 875);usleep(200000) 

--ot("Reset.cancel",5) for i, v in pairs(findImage(r("Reset.cancel"), 1, 0.98, region, false)) do;--tap(v[1], v[2]);usleep(300000)
tap(math.random(75,650), 1150);     usleep(10000); 
toast("\n\n"..trx,6);
toast("\n\n"..trx,6)
toast("⭕️ MAX2020Pre                  "..getSN(),6);
toast("⭕️ MAX2020Pre                  "..getSN(),6);
keyDown(KEY_TYPE.HOME_BUTTON);
usleep(186936.67);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(163298.17);
keyUp(KEY_TYPE.HOME_BUTTON);
usleep(2000000);
for i, v in pairs(findImage(r("fixFacetimeAlert"), 1, 0.98, region, false)) do;
tap(515, 760);usleep(500000);end;--fixFacetimeAlert	
file = io.open(r(".../.../temmp/ResetOK",1), "w");file:write("OK");file:close()				
end;--Reset.Applications.png
io.popen('activator send libactivator.profile.Default')
appKill("com.tigisoftware.ADManager");usleep(500000);  
end;--ResetApp()
--================================================================
function XY(var)	--getclipboard
	XY = "NO"
	OKZ = "NO"
	nameInputvalue = var
if nameInputvalue == "" then
		OKZ = "OK"
    elseif nameInputvalue == nil then
		OKZ = "OK"		
	else
str = nameInputvalue
if string.find(str, "a") or string.find(str, "c") or string.find(str, "d")  or string.find(str, "e") or string.find(str, "f") or string.find(str, "g") or string.find(str, "h") or string.find(str, "i") or string.find(str, "j") or string.find(str, "k") or string.find(str, "l") or string.find(str, "m") or string.find(str, "n") or string.find(str, "o") or string.find(str, "p") or string.find(str, "q") or string.find(str, "s") or string.find(str, "r") or string.find(str, "q") or string.find(str, "z") or string.find(str, "v") then
 toast("Vui lòng nhập đúng định dạng, \nVD: 1-9  1-237  109-295 ")
else	
		 if (string.len(nameInputvalue))<8 then
		 if (string.len(nameInputvalue))>2 then
str = nameInputvalue
if string.find(str, "-") then
function split(str,sep)
if sep == nil then
    words = {}
    for word in str:gmatch("%w+") do table.insert(words, word) end
    return words
end
return {str:match((str:gsub("[^"..sep.."]*"..sep, "([^"..sep.."]*)"..sep)))} -- BUG!! doesnt return last value
end
local str = ""..nameInputvalue.."-OK"
local sep = "-"
t = split(str,sep); usleep(500000);
			if 	tonumber(t[1]) < tonumber(t[2]) then							
if 	tonumber(t[2]) < 501 then
			if	tonumber(t[2]) < count("LIVE") or tonumber(t[2]) == count("LIVE") then
									
XY = "OK"	
OKZ = "OK"
									
	else;toast("Dãy bạn nhập bất thường, khả năng:\n1.Nhập sai, acc Live còn ít.\n2.CheckLive và chạy lại nhé !",10);
			FrankyN0uva(rx(".../MENU3/5.1.1",1));end;--if	t[2] > count("LIVE") then
local f = io.open(r(".../.../temmp/appX.txt",1), "w");f:write(t[1]);f:close()
local f = io.open(r(".../.../temmp/appY.txt",1), "w");f:write(t[2]);f:close()

					else;toast("Vui lòng nhập đúng định dạng, \nVD: 1-9  1-237  109-295 ");end;
					else;toast("Vui lòng nhập đúng định dạng, \nVD: 1-9  1-237  109-295 ");end;		
else; toast("Vui lòng nhập đúng định dạng, \nVD: 1-9  1-237  109-295 ");end; 
else; toast("Vui lòng nhập đúng định dạng, \nVD: 1-9  1-237  109-295 ");end;
else; toast("Vui lòng nhập đúng định dạng, \nVD: 1-9  1-237  109-295 ");end;
end;
end;
	return OKZ
end;--end XY(TOSTRING(NAMEINPUT.VALUE)

local date = os.date("%d/%m/%Y");
local f = io.open(r(".../.../temmp/d",1), "rb"); local dat3 = f:read("*all"); f:close(); 
local f = io.open(r(".../.../temmp/IDapp.txt",1), "rb"); local IDapp = f:read("*all"); f:close();

local label = {type=CONTROLLER_TYPE.LABEL, text="⭕MAX2020(Premium)           FrankyNouva\n                                                      0933.998.772"}
local btn = {type=CONTROLLER_TYPE.BUTTON, title="🔙   "..date, color=0xFF5733, width=0.5, flag=20, collectInputs=true}
local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="Start", color=0x71C69E, width=1.0, flag=1, collectInputs=true}
local developerSwitch = {type=CONTROLLER_TYPE.SWITCH, title="CheckLive: "..count("LIVE").."/"..count("GONE").."/"..count("ACC").." ("..IDapp..") Checked: "..dat3, key="CheckLive", value=1}
local btn30 = {type=CONTROLLER_TYPE.BUTTON, title="THOÁT", color=0xFF5733, width=1.0, flag=30, collectInputs=true}
local nameInput = {type=CONTROLLER_TYPE.INPUT, title="✅ ReactIDpost: Run X-Y    ", key="Name", value="1-"..count("LIVE")}
--local nameInput1 = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="Bước 1: Copy link bạn cần React"}
local nameInput2 = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="Dán link bài vào đây: "}

local nameInput6 = {type=CONTROLLER_TYPE.INPUT, title="\n😎 Thiết Lập Sau Action chính:", key="Name", value="Số Post dc ReactNewsfeed: 1"}
local nameInput7 = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="Số Acc dc ReactAccList: 0"}
local nameInput8 = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="Số Acc dc ReactProfileList: 0"}
local nameInput9 = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="Số Page dc ReactPageList : 0"}
local nameInput10 = {type=CONTROLLER_TYPE.INPUT, title="", key="Name", value="Số lặp ActionFakeUser: 1"}

local controls = {label, btn,btn1, developerSwitch,nameInput,nameInput2,nameInput6,nameInput7,nameInput8,nameInput9,nameInput10, btn30}
local result = dialog(controls, orientations);


if (result == 20) then
FrankyN0uva(rx(".../MENU2/5.1",1))			
elseif (result == 1) then
A1 = "1"
A2 = nameInput2.value
A6 = string.match(nameInput6.value,"%d+")	
A7 = string.match(nameInput7.value,"%d+")
A8 = string.match(nameInput8.value,"%d+")
A9 = string.match(nameInput9.value,"%d+")
A10 = string.match(nameInput10.value,"%d+")
	
	
	if  string.find(nameInput2.value, "facebook") == nil then
		toast("Bạn nhập link này sao chạy dc\n\n"..nameInput2.value,5);FrankyN0uva(rx(".../MENU3/5.1.1",1))
   elseif 	A7 ==  nil or A8 ==  nil or A9 ==  nil or A10 ==  nil or tonumber(A7) >10 or tonumber(A8) > 10 or tonumber(A9) >10 or tonumber(A10) >10 then
toast("Nhập lại thông số, giá trị từ '0-10'",5);FrankyN0uva(rx(".../MENU3/5.1.1",1))
	elseif tonumber(A7) <11 and tonumber(A8) < 11 and tonumber(A9) <11 and tonumber(A10) <11 then
		local f = io.open(r(".../.../temmp/A1",1), "w");f:write(A1);f:close()
		
local f = io.open(r(".../.../temmp/A2",1), "w");f:write(A2);f:close()
		
local f = io.open(r(".../.../temmp/A6",1), "w");f:write(A6);f:close()
local f = io.open(r(".../.../temmp/A7",1), "w");f:write(A7);f:close()
local f = io.open(r(".../.../temmp/A8",1), "w");f:write(A8);f:close()
local f = io.open(r(".../.../temmp/A9",1), "w");f:write(A9);f:close()
local f = io.open(r(".../.../temmp/A10",1), "w");f:write(A10);f:close()
XY(nameInput.value)	
		if OKZ == "OK" then
			
if developerSwitch.value == 1 then

local f = io.open(r(".../.../temmp/c",1), "w");f:write("OK");f:close()			
	else
local f = io.open(r(".../.../temmp/c",1), "w");f:write("NO");f:close()			
    end;--if developerSwitch.value == 1 then
local f = io.open(r(".../.../temmp/appZ",1), "w");f:write("com.facebook.FrankyNouva");f:close();usleep(100000);		
FrankyN0uva(rx(".../temmp2/5.1.1",1))				
			else;end;--if OKZ == "OK" then
		else;end;--if 	A7 ==  nil
	else
	end;